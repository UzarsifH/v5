/**
 * تنظیمات اصلی اپ فُرجا
 * (قبلاً این مقادیر در دیتابیس / پنل ادمین بود؛ حالا اینجا ثابت‌اند.)
 */
export const APP_CONFIG = {
  appName: "فُرجا",
  /** باید با appId داخل capacitor.config.json و پنل مایکت یکی باشد */
  packageName: "ir.forja.app",
  /** قیمت اشتراک ماهانه (تومان) */
  monthlyPrice: 249000,
  /** شناسه‌ی محصول (SKU) اشتراک ماهانه در پنل مایکت */
  sku: "M2",
  /** برای سازگاری با کدهای قدیمی نگه داشته شده؛ پرداخت همیشه واقعی (مایکت) است */
  paymentMode: "live" as "sandbox" | "live",
  /** شناسه‌ی برنامه در پنل مایکت (فقط برای مرجع) */
  myketAppId: "ed094228-0fdd-4274-8d8e-d1d84c5011c5",
  /** Supabase (کلید publishable عمومی است و طبق طراحی داخل اپ قرار می‌گیرد) */
  supabaseUrl: "https://fmpkueeghxzleknsqlkt.supabase.co",
  supabaseKey: "sb_publishable_zq2wk9CLunDukELjHwTLQw_mObMnE7v",
  /** مدت اعتبار هر اشتراک (روز) */
  subscriptionDays: 30,
};
