/**
 * پرداخت درون‌برنامه‌ای مایکت (IAB v3) از طریق پلاگین بومی MyketBilling
 * (کد جاوا: native/android — با scripts/patch-android.mjs داخل پروژه اندروید گذاشته می‌شود)
 *
 * نکته‌ی امنیتی: رسید اینجا «تأیید» نمی‌شود. فقط توکن خرید به سرور می‌رود و Edge Function
 * آن را سرور‌به‌سرور از مایکت استعلام می‌کند و بعد اشتراک را فعال می‌کند.
 */
import { Capacitor, registerPlugin } from "@capacitor/core";

export type MyketPurchase = {
  orderId?: string;
  packageName?: string;
  productId?: string;
  purchaseTime?: number;
  purchaseState?: number;
  developerPayload?: string;
  purchaseToken?: string;
};

type Raw = { purchaseData: string; signature: string };

const Native = registerPlugin<{
  check(): Promise<{ installed: boolean; supported: boolean; code: number }>;
  purchase(o: { sku: string; payload: string }): Promise<Raw>;
  owned(): Promise<{ items: Raw[] }>;
  consume(o: { purchaseToken: string }): Promise<{ code: number }>;
}>("MyketBilling");

export const isNativeAndroid = () => Capacitor.getPlatform() === "android";

export class MyketError extends Error {
  code: string;
  constructor(message: string, code: string) {
    super(message);
    this.code = code;
  }
  get canceled() {
    return this.code === "1";
  }
}

/** کدهای پاسخ استاندارد IAB v3 به پیام قابل فهم */
const MESSAGES: Record<string, string> = {
  NO_MYKET: "مایکت روی این گوشی نصب نیست. مایکت را نصب کن و وارد حسابت شو.",
  "1": "پرداخت لغو شد.",
  "2": "سرویس مایکت در دسترس نیست. اینترنت را چک کن و مایکت را به‌روز کن.",
  "3": "پرداخت مایکت روی این گوشی فعال نیست. مایکت را به‌روز کن و وارد حسابت شو.",
  "4": "این محصول در پنل مایکت پیدا نشد یا فعال نیست (شناسه محصول را در پنل چک کن).",
  "5": "تنظیمات اپ با پنل مایکت نمی‌خواند (نام پکیج یا امضای APK با نسخه‌ی ثبت‌شده در مایکت یکی نیست).",
  "6": "خطای مایکت. دوباره تلاش کن.",
  "7": "این محصول قبلاً خریداری شده و هنوز ثبت نشده است.",
  "8": "این خرید روی حساب مایکت تو نیست.",
};

function toError(e: unknown): MyketError {
  if (e instanceof MyketError) return e;
  const o = (e ?? {}) as { code?: unknown; message?: unknown };
  const code = o.code != null ? String(o.code) : "6";
  const raw = typeof o.message === "string" ? o.message : "";
  return new MyketError(MESSAGES[code] ?? (raw || MESSAGES["6"]), code);
}

function parse(raw: Raw): MyketPurchase {
  return JSON.parse(raw.purchaseData) as MyketPurchase;
}

/** قبل از خرید: مایکت نصب است و پرداخت درون‌برنامه‌ای را پشتیبانی می‌کند؟ */
export async function checkBilling(): Promise<void> {
  if (!isNativeAndroid()) throw new MyketError("پرداخت فقط داخل اپ نصب‌شده روی اندروید ممکن است.", "NO_ANDROID");
  try {
    const r = await Native.check();
    if (!r.installed) throw new MyketError(MESSAGES.NO_MYKET, "NO_MYKET");
    if (!r.supported) throw new MyketError(MESSAGES[String(r.code)] ?? MESSAGES["3"], String(r.code));
  } catch (e) {
    throw toError(e);
  }
}

/** خریدهای مصرف‌نشده‌ی همین محصول (برای بازیابی پرداخت‌هایی که وسط راه قطع شده‌اند) */
export async function ownedPurchases(sku: string): Promise<MyketPurchase[]> {
  if (!isNativeAndroid()) return [];
  try {
    const { items } = await Native.owned();
    return items.map(parse).filter((p) => p.productId === sku && p.purchaseState === 0 && p.purchaseToken);
  } catch {
    return [];
  }
}

/** شروع خرید. اگر قبلاً خریده شده ولی مصرف نشده بود، همان خرید برگردانده می‌شود */
export async function buy(sku: string, payload: string): Promise<MyketPurchase> {
  try {
    const p = parse(await Native.purchase({ sku, payload }));
    if (p.purchaseState !== 0 || !p.purchaseToken) throw new MyketError("رسید مایکت معتبر نبود.", "6");
    return p;
  } catch (e) {
    const err = toError(e);
    if (err.code === "7") {
      const mine = await ownedPurchases(sku);
      if (mine.length) return mine[0];
    }
    throw err;
  }
}

/** بعد از ثبت اشتراک روی سرور صدا زده می‌شود تا ماه بعد دوباره قابل خرید باشد */
export const consume = (purchaseToken: string) => Native.consume({ purchaseToken }).catch(() => null);
