import { apiFetch } from "@/lib/api";
import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "@/lib/nav";
import { RippleButton, useAuth } from "@/components/Providers";
import { formatToman } from "@/lib/format";
import { buy, checkBilling, consume, MyketError, ownedPurchases, type MyketPurchase } from "@/lib/myket";

type Init = { paymentId: number; amount: number; sku: string; payload: string; packageName: string };
type Phase = "idle" | "paying" | "verifying";

async function postJson(url: string, body: unknown) {
  const res = await apiFetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  const data = (await res.json()) as { ok?: boolean; error?: string };
  return { ok: Boolean(data.ok), error: data.error || "" };
}

export default function PayPage() {
  const { user, loading, refresh } = useAuth();
  const router = useRouter();
  const [init, setInit] = useState<Init | null>(null);
  const [error, setError] = useState("");
  const [code, setCode] = useState("");
  const [phase, setPhase] = useState<Phase>("idle");
  const [info, setInfo] = useState("");
  // خریدی که در مایکت انجام شده ولی هنوز روی سرور ثبت نشده (مثلاً اینترنت قطع شد)؛ با «تأیید دوباره» ثبت می‌شود
  const [pending, setPending] = useState<MyketPurchase | null>(null);
  const recovered = useRef(false);

  useEffect(() => {
    if (!loading && !user) router.replace("/login");
  }, [loading, user, router]);

  const loadInit = useCallback(async () => {
    setError("");
    try {
      const res = await apiFetch("/api/payment/myket/init", { method: "POST" });
      const d = await res.json();
      if (d.ok) setInit(d as Init);
      else setError(d.error || "خطا در شروع پرداخت");
    } catch {
      setError("اتصال برقرار نشد. اینترنت را چک کن.");
    }
  }, []);

  useEffect(() => {
    void loadInit();
  }, [loadInit]);

  /** ثبت خرید روی سرور → فعال‌سازی اشتراک → مصرف خرید در مایکت */
  const finish = useCallback(
    async (purchase: MyketPurchase, paymentId: number | null) => {
      setPhase("verifying");
      setError("");
      setCode("");
      setPending(purchase);
      const r = await postJson("/api/payment/myket/verify", { paymentId, purchase });
      if (!r.ok) {
        setPhase("idle");
        setError(r.error || "تأیید پرداخت ناموفق بود");
        return false;
      }
      if (purchase.purchaseToken) await consume(purchase.purchaseToken); // تا ماه بعد دوباره قابل خرید باشد
      setPending(null);
      await refresh();
      router.replace("/assess");
      return true;
    },
    [refresh, router],
  );

  // بازیابی: اگر قبلاً پرداخت شده ولی اشتراک ثبت نشده، خودکار ثبت کن
  useEffect(() => {
    if (!init || recovered.current) return;
    recovered.current = true;
    void ownedPurchases(init.sku).then((list) => {
      if (list.length) {
        setInfo("یک پرداخت قبلی ثبت‌نشده پیدا شد؛ در حال فعال‌سازی اشتراک…");
        void finish(list[0], init.paymentId).finally(() => setInfo(""));
      }
    });
  }, [init, finish]);

  async function pay() {
    if (!init || phase !== "idle") return;
    setError("");
    setCode("");
    if (pending) {
      await finish(pending, init.paymentId);
      return;
    }
    setPhase("paying");
    try {
      await checkBilling();
      const purchase = await buy(init.sku, init.payload);
      await finish(purchase, init.paymentId);
    } catch (e) {
      const err = e instanceof MyketError ? e : new MyketError(e instanceof Error ? e.message : "پرداخت انجام نشد", "6");
      setPhase("idle");
      setError(err.message);
      setCode(err.code);
      void postJson("/api/payment/myket/fail", { paymentId: init.paymentId, canceled: err.canceled, error: `${err.code}: ${err.message}` });
    }
  }

  const busy = phase !== "idle";
  const label = phase === "paying" ? "در حال پرداخت…" : phase === "verifying" ? "در حال تأیید پرداخت…" : pending ? "تأیید دوباره‌ی پرداخت" : "پرداخت و فعال‌سازی اشتراک";

  return (
    <div className="px-5 pt-10">
      <button className="text-sm text-white/50" onClick={() => router.back()} disabled={busy}>
        بازگشت
      </button>
      <div className="card mt-5 overflow-hidden">
        <div className="bg-[#0b1b12] p-5">
          <p className="text-xs text-[#9be15d]">پرداخت امن با مایکت</p>
          <h1 className="mt-2 text-2xl font-extrabold">اشتراک ماهانه فُرجا</h1>
        </div>
        <div className="p-5">
          {init ? (
            <>
              <Row k="محصول" v="اشتراک ماهانه" />
              <Row k="مبلغ" v={formatToman(init.amount)} />
              <Row k="مدت" v="۳۰ روز" />
            </>
          ) : error ? null : (
            <p className="text-sm text-[var(--muted)]">در حال آماده‌سازی...</p>
          )}
          {info ? <p className="mt-3 text-sm text-[var(--lime)]">{info}</p> : null}
          {pending && !busy ? <p className="mt-3 text-xs leading-6 text-white/60">پرداخت تو در مایکت انجام شده؛ فقط ثبت اشتراک مانده. دکمه‌ی زیر را بزن.</p> : null}
          {error ? <p className="mt-3 text-sm leading-7 text-[var(--danger)]">{error}</p> : null}
          {code ? (
            <p className="mt-1 text-[10px] text-white/30" dir="ltr">
              myket-code: {code}
            </p>
          ) : null}
          {!init && error ? (
            <RippleButton className="btn-lime btn-full mt-5" onClick={() => void loadInit()}>
              تلاش دوباره
            </RippleButton>
          ) : (
            <RippleButton className="btn-lime btn-full mt-5" disabled={!init || busy} onClick={pay}>
              {label}
            </RippleButton>
          )}
          <p className="mt-3 text-[11px] leading-6 text-white/40">اشتراک فقط بعد از پرداخت موفق در مایکت و تأیید سرور فعال می‌شود.</p>
          <p className="mt-2 text-[10px] text-white/25" dir="ltr">
            {init?.packageName} · {init?.sku} · {__BUILD__}
          </p>
        </div>
      </div>
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex items-center justify-between border-b border-white/5 py-2 text-xs">
      <span className="text-white/40">{k}</span>
      <span className="font-bold">{v}</span>
    </div>
  );
}
