// Supabase Edge Function: تأیید سرور‌به‌سرور خرید مایکت و فعال‌سازی اشتراک
// مستند مایکت: POST https://developer.myket.ir/api/partners/applications/{PACKAGE}/purchases/products/{SKU}/verify
//   Header: X-Access-Token   Body: { "tokenId": "<purchaseToken>" }
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

const PACKAGE = Deno.env.get("APP_PACKAGE") ?? "ir.forja.app";
const SKU = Deno.env.get("APP_SKU") ?? "M2";
const MYKET_TOKEN = Deno.env.get("MYKET_ACCESS_TOKEN") ?? "";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...cors, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ ok: false, error: "method" }, 405);

  try {
    if (!MYKET_TOKEN) return json({ ok: false, error: "MYKET_ACCESS_TOKEN روی سرور تنظیم نشده" }, 500);

    const url = Deno.env.get("SUPABASE_URL")!;
    const admin = createClient(url, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });

    // کاربر از روی JWT
    const jwt = (req.headers.get("Authorization") ?? "").replace(/^Bearer\s+/i, "");
    const { data: u, error: ue } = await admin.auth.getUser(jwt);
    if (ue || !u?.user) return json({ ok: false, error: "نشست منقضی شده؛ دوباره وارد شو" }, 401);
    const uid = u.user.id;

    const body = await req.json().catch(() => ({}));
    const token = String(body?.purchaseToken ?? "").trim();
    const sku = String(body?.sku ?? "");
    const paymentId = Number(body?.paymentId) || null;
    if (token.length < 5 || sku !== SKU) return json({ ok: false, error: "اطلاعات خرید نامعتبر است" }, 400);

    // ۱) استعلام از مایکت
    const r = await fetch(
      `https://developer.myket.ir/api/partners/applications/${encodeURIComponent(PACKAGE)}/purchases/products/${encodeURIComponent(SKU)}/verify`,
      { method: "POST", headers: { "X-Access-Token": MYKET_TOKEN, "Content-Type": "application/json" }, body: JSON.stringify({ tokenId: token }) },
    );
    if (!r.ok) {
      console.error("myket verify http", r.status);
      const msg = r.status === 401 || r.status === 403 ? "توکن دسترسی مایکت (X-Access-Token) درست نیست" : "مایکت این خرید را تأیید نکرد";
      return json({ ok: false, error: msg, code: r.status }, 422);
    }
    const m = (await r.json()) as { purchaseState?: number; developerPayload?: string };
    if (m.purchaseState !== 0) return json({ ok: false, error: "این خرید در مایکت موفق نیست" }, 422);

    // ۲) payload باید متعلق به همین کاربر باشد (اگر مایکت برگردانده باشد)
    const dp = m.developerPayload ?? "";
    if (dp && !dp.startsWith(`forja:${uid}:`)) return json({ ok: false, error: "این خرید مربوط به حساب دیگری است" }, 403);

    // ۳) فعال‌سازی اتمیک (توکن یکتاست؛ تکراری = بدون تمدید دوباره)
    const grant = () =>
      admin.rpc("grant_payment", { p_user: uid, p_payment_id: paymentId, p_sku: SKU, p_token: token, p_order_id: String(body?.orderId ?? "").slice(0, 80) || null, p_payload: dp || null });
    let { data, error } = await grant();
    if (error?.code === "23505") ({ data, error } = await grant()); // رقابت دو درخواست همزمان
    if (error) {
      console.error("grant_payment", error.message);
      return json({ ok: false, error: error.message.includes("token_other_user") ? "این خرید قبلاً برای حساب دیگری ثبت شده" : "ثبت اشتراک ناموفق بود" }, 422);
    }
    return json({ ok: true, ...(data as Record<string, unknown>) });
  } catch (e) {
    console.error(e);
    return json({ ok: false, error: "خطای سرور" }, 500);
  }
});
