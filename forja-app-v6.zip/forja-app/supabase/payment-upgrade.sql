-- =====================================================================
-- ارتقای سیستم پرداخت مایکت (v6)
-- این فایل را یک بار در Supabase → SQL Editor اجرا کن (چندبار اجرا هم بی‌خطر است).
-- تغییر اصلی: تأیید خرید دیگر از طرف گوشی قبول نمی‌شود؛ فقط Edge Function (با کلید سرویس)
-- بعد از تأیید سرور‌به‌سرور مایکت، اشتراک را فعال می‌کند.
-- =====================================================================

-- ۱) مسیر ناامن قبلی (گوشی خودش رسید را «تأیید» می‌کرد) حذف می‌شود
drop function if exists public.complete_payment(bigint, jsonb);

-- ۲) فعال‌سازی اشتراک — فقط برای service_role (Edge Function)
create or replace function public.grant_payment(
  p_user uuid, p_payment_id bigint, p_sku text, p_token text, p_order_id text, p_payload text
) returns jsonb
language plpgsql security definer set search_path = public as $$
declare r public.payments%rowtype; v_until timestamptz;
begin
  if p_user is null or p_token is null or length(p_token) < 5 then raise exception 'bad_args'; end if;

  -- این توکن قبلاً ثبت شده؟ (تکراری = بدون تمدید دوباره)
  select * into r from public.payments where purchase_token = p_token;
  if found then
    if r.user_id is distinct from p_user then raise exception 'token_other_user'; end if;
    select premium_until into v_until from public.profiles where id = p_user;
    return jsonb_build_object('premium_until', v_until, 'already', true);
  end if;

  -- ردیف پرداخت خود کاربر (اگر هنوز موفق نشده)
  r := null;
  if p_payment_id is not null then
    select * into r from public.payments
     where id = p_payment_id and user_id = p_user and status in ('pending', 'failed', 'canceled') for update;
  end if;

  -- بازیابی خرید (مثلاً پرداخت انجام شده ولی اپ قبل از تأیید بسته شد): ردیف جدید می‌سازیم
  if r.id is null then
    insert into public.payments(user_id, phone, sku, amount, payload, status, source)
    select p_user, phone, p_sku, public.get_price(), p_payload, 'pending', 'myket'
      from public.profiles where id = p_user
    returning * into r;
    if r.id is null then raise exception 'profile_not_found'; end if;
  end if;

  update public.payments
     set status = 'success', purchase_token = p_token, order_id = p_order_id, error = null, updated_at = now()
   where id = r.id;

  update public.profiles
     set premium_until = greatest(now(), coalesce(premium_until, now())) + make_interval(days => 30)
   where id = p_user returning premium_until into v_until;

  return jsonb_build_object('premium_until', v_until);
end $$;

revoke execute on function public.grant_payment(uuid, bigint, text, text, text, text) from public, anon, authenticated;
grant  execute on function public.grant_payment(uuid, bigint, text, text, text, text) to service_role;

-- ۳) سایر توابع پرداخت برای کاربر لاگین‌شده باقی می‌مانند
grant execute on function public.begin_payment(text), public.fail_payment(bigint, text, text) to authenticated;
