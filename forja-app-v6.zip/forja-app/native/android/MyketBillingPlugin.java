package __APP_ID__;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import com.android.vending.billing.IInAppBillingService;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

/**
 * پرداخت درون‌برنامه‌ای مایکت (پروتکل IAB v3 — مستند مایکت)
 * bind: ir.mservices.market.InAppBillingService.BIND  |  permission: ir.mservices.market.BILLING
 * کدهای پاسخ: 0 موفق، 1 لغو، 2 سرویس در دسترس نیست، 3 پرداخت در دسترس نیست، 4 محصول نامعتبر،
 *             5 خطای توسعه‌دهنده (پکیج/امضا)، 6 خطا، 7 قبلاً خریده شده، 8 مالک نیست
 */
@CapacitorPlugin(name = "MyketBilling")
public class MyketBillingPlugin extends Plugin {
    private static final String MARKET = "ir.mservices.market";
    private static final String BIND = "ir.mservices.market.InAppBillingService.BIND";
    private static final int API = 3;
    private static final String TYPE = "inapp";

    private IInAppBillingService svc;
    private ServiceConnection conn;
    private boolean binding = false;
    private final List<Ready> waiters = new ArrayList<>();

    private interface Ready { void onReady(IInAppBillingService s); }
    private interface Job { void run(IInAppBillingService s) throws Exception; }

    /* ───────── اتصال به سرویس مایکت (یک bind مشترک) ───────── */

    private void connect(final Ready cb) {
        boolean startBind = false;
        synchronized (this) {
            if (svc != null) { final IInAppBillingService s = svc; cb.onReady(s); return; }
            waiters.add(cb);
            if (!binding) { binding = true; startBind = true; }
        }
        if (!startBind) return;

        conn = new ServiceConnection() {
            @Override public void onServiceConnected(ComponentName n, IBinder b) {
                synchronized (MyketBillingPlugin.this) { svc = IInAppBillingService.Stub.asInterface(b); }
                flush(svc);
            }
            @Override public void onServiceDisconnected(ComponentName n) {
                synchronized (MyketBillingPlugin.this) { svc = null; binding = false; }
            }
        };
        Intent i = new Intent(BIND);
        i.setPackage(MARKET);
        boolean ok = false;
        try { ok = getContext().bindService(i, conn, Context.BIND_AUTO_CREATE); } catch (Exception e) { ok = false; }
        if (!ok) flush(null);
    }

    private void flush(IInAppBillingService s) {
        List<Ready> copy;
        synchronized (this) {
            copy = new ArrayList<>(waiters);
            waiters.clear();
            if (s == null) binding = false;
        }
        for (Ready r : copy) r.onReady(s);
    }

    /** اجرای کار روی ترد جدا (فراخوانی binder روی main thread ممنوع است) */
    private void withService(final PluginCall call, final Job job) {
        connect(s -> {
            if (s == null) { call.reject("مایکت روی این گوشی نصب نیست یا سرویس پرداختش در دسترس نیست.", "NO_MYKET"); return; }
            new Thread(() -> {
                try { job.run(s); }
                catch (Exception e) { call.reject("خطا در ارتباط با مایکت: " + e.getMessage(), "6"); }
            }).start();
        });
    }

    private static int codeOf(Bundle b) {
        if (b == null) return 6;
        Object o = b.get("RESPONSE_CODE");
        if (o == null) return 0;
        if (o instanceof Integer) return (Integer) o;
        if (o instanceof Long) return (int) ((Long) o).longValue();
        return 6;
    }

    /* ───────── آیا پرداخت مایکت روی این گوشی فعال است؟ ───────── */

    @PluginMethod
    public void check(final PluginCall call) {
        connect(s -> {
            if (s == null) {
                JSObject r = new JSObject(); r.put("installed", false); r.put("supported", false); r.put("code", -1);
                call.resolve(r);
                return;
            }
            new Thread(() -> {
                try {
                    int rc = s.isBillingSupported(API, getContext().getPackageName(), TYPE);
                    JSObject r = new JSObject(); r.put("installed", true); r.put("supported", rc == 0); r.put("code", rc);
                    call.resolve(r);
                } catch (Exception e) { call.reject("خطا در ارتباط با مایکت: " + e.getMessage(), "6"); }
            }).start();
        });
    }

    /* ───────── خرید ───────── */

    @PluginMethod
    public void purchase(final PluginCall call) {
        final String sku = call.getString("sku");
        final String payload = call.getString("payload", "");
        if (sku == null || sku.isEmpty()) { call.reject("شناسه محصول خالی است", "4"); return; }
        if (!(getActivity() instanceof ComponentActivity)) { call.reject("اکتیویتی آماده نیست", "6"); return; }

        withService(call, s -> {
            Bundle b = s.getBuyIntent(API, getContext().getPackageName(), sku, TYPE, payload);
            int rc = codeOf(b);
            if (rc != 0) { call.reject("پاسخ مایکت: " + rc, String.valueOf(rc)); return; }
            final PendingIntent pi = b.getParcelable("BUY_INTENT");
            if (pi == null) { call.reject("مایکت صفحه پرداخت را برنگرداند", "6"); return; }

            final ComponentActivity act = (ComponentActivity) getActivity();
            act.runOnUiThread(() -> {
                final AtomicReference<ActivityResultLauncher<IntentSenderRequest>> ref = new AtomicReference<>();
                final ActivityResultLauncher<IntentSenderRequest> launcher = act.getActivityResultRegistry().register(
                    "myket_buy_" + System.nanoTime(),
                    new ActivityResultContracts.StartIntentSenderForResult(),
                    result -> {
                        ActivityResultLauncher<IntentSenderRequest> self = ref.get();
                        if (self != null) self.unregister();
                        onBuyResult(call, result.getResultCode(), result.getData());
                    });
                ref.set(launcher);
                try {
                    launcher.launch(new IntentSenderRequest.Builder(pi.getIntentSender()).build());
                } catch (Exception e) {
                    launcher.unregister();
                    call.reject("باز کردن صفحه پرداخت مایکت ممکن نشد", "6");
                }
            });
        });
    }

    private void onBuyResult(PluginCall call, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_CANCELED) { call.reject("پرداخت لغو شد", "1"); return; }
        if (data == null) { call.reject("پاسخی از مایکت نیامد", "6"); return; }
        int rc = codeOf(data.getExtras());
        String pd = data.getStringExtra("INAPP_PURCHASE_DATA");
        String sig = data.getStringExtra("INAPP_DATA_SIGNATURE");
        if (resultCode == Activity.RESULT_OK && rc == 0 && pd != null) {
            JSObject o = new JSObject();
            o.put("purchaseData", pd);
            o.put("signature", sig == null ? "" : sig);
            call.resolve(o);
        } else {
            call.reject(rc == 1 ? "پرداخت لغو شد" : "پرداخت انجام نشد (" + rc + ")", String.valueOf(rc));
        }
    }

    /* ───────── خریدهای مصرف‌نشده (برای بازیابی) ───────── */

    @PluginMethod
    public void owned(final PluginCall call) {
        withService(call, s -> {
            JSArray arr = new JSArray();
            String cont = null;
            do {
                Bundle b = s.getPurchases(API, getContext().getPackageName(), TYPE, cont);
                int rc = codeOf(b);
                if (rc != 0) { call.reject("خطا در دریافت خریدها (" + rc + ")", String.valueOf(rc)); return; }
                ArrayList<String> d = b.getStringArrayList("INAPP_PURCHASE_DATA_LIST");
                ArrayList<String> sg = b.getStringArrayList("INAPP_DATA_SIGNATURE_LIST");
                if (d != null) for (int i = 0; i < d.size(); i++) {
                    JSObject o = new JSObject();
                    o.put("purchaseData", d.get(i));
                    o.put("signature", sg != null && i < sg.size() ? sg.get(i) : "");
                    arr.put(o);
                }
                cont = b.getString("INAPP_CONTINUATION_TOKEN");
            } while (cont != null);
            JSObject r = new JSObject(); r.put("items", arr); call.resolve(r);
        });
    }

    /* ───────── مصرف خرید (تا ماه بعد دوباره قابل خرید باشد) ───────── */

    @PluginMethod
    public void consume(final PluginCall call) {
        final String token = call.getString("purchaseToken");
        if (token == null || token.isEmpty()) { call.reject("توکن خالی است", "6"); return; }
        withService(call, s -> {
            int rc = s.consumePurchase(API, getContext().getPackageName(), token);
            JSObject r = new JSObject(); r.put("code", rc); call.resolve(r);
        });
    }

    @Override
    protected void handleOnDestroy() {
        try { if (conn != null) getContext().unbindService(conn); } catch (Exception ignored) { }
        synchronized (this) { svc = null; binding = false; }
        super.handleOnDestroy();
    }
}
