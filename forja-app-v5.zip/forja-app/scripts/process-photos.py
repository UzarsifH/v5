# عکس‌های دانلودشده را کم‌حجم (~۶۰ تا ۹۰ کیلوبایت) و هم‌رنگ (تیره + کمی سبز-لیمویی) می‌کند
import os, glob
from PIL import Image, ImageEnhance, ImageOps
import numpy as np
os.makedirs("public/images/photos", exist_ok=True)
n = 0
for f in glob.glob("tmp_raw/*.jpg"):
    slot = os.path.basename(f)[:-4]
    try:
        im = Image.open(f).convert("RGB")
        im = ImageOps.fit(im, (720, 960), Image.LANCZOS, centering=(0.5, 0.4)) if im.width < im.height * 0.9 else ImageOps.fit(im, (720, 960), Image.LANCZOS, centering=(0.5, 0.4))
        im = ImageEnhance.Contrast(im).enhance(1.10); im = ImageEnhance.Color(im).enhance(0.88); im = ImageEnhance.Brightness(im).enhance(0.9)
        a = np.asarray(im).astype("float32")
        tint = np.array([200, 245, 66], "float32")
        a = a * 0.93 + tint * 0.07 * (a.mean(axis=2, keepdims=True) / 255)          # رنگ‌بندی یکدست
        yy = np.linspace(0, 1, a.shape[0])[:, None, None]
        a = a * (1 - 0.35 * yy ** 2)                                                 # پایین کمی تیره‌تر
        Image.fromarray(np.clip(a, 0, 255).astype("uint8")).save(f"public/images/photos/{slot}.jpg", quality=72, optimize=True, progressive=True)
        n += 1
    except Exception as e:
        print("skip", slot, e)
print(n, "photos processed")
