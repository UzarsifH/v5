# آیکون اپ، لوگوی شفاف و اسپلش را از brand/logo.png می‌سازد (بعد از make-art اجرا شود)
import numpy as np, os
from PIL import Image, ImageFilter
src = Image.open("brand/logo.png").convert("RGB")
a = np.asarray(src).astype("float32")
mx = a.max(axis=2)
alpha = np.clip((mx - 48) / 50, 0, 1)            # مشکی -> شفاف (لوگو روی پس‌زمینه‌ی مشکی همان شکل می‌ماند)
rgba = np.dstack([a, alpha * 255]).astype("uint8")
logo = Image.fromarray(rgba, "RGBA")
bbox = logo.split()[3].point(lambda v: 255 if v > 40 else 0).getbbox()
logo = logo.crop(bbox)
BG = (8, 8, 10)

def fit(size, frac):
    w, h = logo.size; s = size * frac / max(w, h)
    return logo.resize((int(w * s), int(h * s)), Image.LANCZOS)
def centered(base, img):
    base.alpha_composite(img, ((base.width - img.width) // 2, (base.height - img.height) // 2)); return base

os.makedirs("assets", exist_ok=True); os.makedirs("public/images", exist_ok=True)
S = 1024
Image.new("RGB", (S, S), BG).save("assets/icon-background.png")
centered(Image.new("RGBA", (S, S), (0, 0, 0, 0)), fit(S, .60)).save("assets/icon-foreground.png")
centered(Image.new("RGBA", (S, S), BG + (255,)), fit(S, .74)).convert("RGB").save("assets/icon-only.png")
sp = Image.new("RGBA", (2732, 2732), BG + (255,)); centered(sp, fit(2732, .34)); sp.convert("RGB").save("assets/splash.png"); sp.convert("RGB").save("assets/splash-dark.png")
fit(512, 1).save("public/images/logo.png", optimize=True)
fit(512, 1).save("public/images/logo-white.png", optimize=True)
print("brand done")
