// بعد از «cap add android» اجرا می‌شود: پلاگین پرداخت مایکت را داخل پروژه‌ی اندروید می‌گذارد.
import fs from "node:fs";
import path from "node:path";
const appId = JSON.parse(fs.readFileSync("capacitor.config.json", "utf8")).appId;
const app = "android/app";
if (!fs.existsSync(app)) { console.error("پوشه android نیست"); process.exit(1); }
const javaDir = path.join(app, "src/main/java", ...appId.split("."));
fs.mkdirSync(javaDir, { recursive: true });
fs.writeFileSync(path.join(javaDir, "MyketBillingPlugin.java"), fs.readFileSync("native/android/MyketBillingPlugin.java", "utf8").replaceAll("__APP_ID__", appId));
fs.writeFileSync(path.join(javaDir, "MainActivity.java"), `package ${appId};

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(MyketBillingPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
`);
const aidl = path.join(app, "src/main/aidl/com/android/vending/billing");
fs.mkdirSync(aidl, { recursive: true });
fs.copyFileSync("native/android/IInAppBillingService.aidl", path.join(aidl, "IInAppBillingService.aidl"));
const gp = path.join(app, "build.gradle"); let g = fs.readFileSync(gp, "utf8");
if (!g.includes("aidl true")) g = g.replace(/^android\s*\{/m, "android {\n    buildFeatures {\n        aidl true\n    }");
if (process.env.KEYSTORE_PATH && !g.includes("signingConfigs {")) {
  const block = `signingConfigs {
        release {
            storeFile file(System.getenv("KEYSTORE_PATH"))
            storePassword System.getenv("KEYSTORE_PASSWORD")
            keyAlias System.getenv("KEY_ALIAS") ?: "forja"
            keyPassword System.getenv("KEYSTORE_PASSWORD")
        }
    }
    `;
  const re = /buildTypes\s*\{\s*release\s*\{/;
  if (!re.test(g)) { console.error("buildTypes.release در build.gradle پیدا نشد"); process.exit(1); }
  g = g.replace(re, (m) => block + m + "\n            signingConfig signingConfigs.release");
}
if (process.env.VERSION_CODE) g = g.replace(/versionCode\s+\d+/, "versionCode " + process.env.VERSION_CODE).replace(/versionName\s+"[^"]*"/, `versionName "1.0.${process.env.VERSION_CODE}"`);
fs.writeFileSync(gp, g);
const mp = path.join(app, "src/main/AndroidManifest.xml"); let m = fs.readFileSync(mp, "utf8");
if (!m.includes("ir.mservices.market.BILLING"))
  m = m.replace("<application", `<uses-permission android:name="ir.mservices.market.BILLING" />\n    <queries>\n        <package android:name="ir.mservices.market" />\n    </queries>\n\n    <application`);
fs.writeFileSync(mp, m);
console.log("✔ پلاگین پرداخت مایکت به پروژه اندروید اضافه شد");
