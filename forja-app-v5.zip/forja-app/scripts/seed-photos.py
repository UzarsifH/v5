# عکس طراحی‌شده را به‌عنوان جایگزین در هر اسلات عکس می‌گذارد (اگر دانلود عکس واقعی نشد، اپ خالی نمی‌ماند)
import re, os, shutil
I, D = "public/images/", "public/images/photos/"
os.makedirs(D, exist_ok=True)
slots = re.findall(r'"((?:ex|m|a)-\w+)"', open("scripts/photo-manifest.mjs", encoding="utf8").read())
ex = dict(re.findall(r'ex\("(\w+)".*?IMG\.(\w+)', open("src/lib/exercises.ts", encoding="utf8").read()))
mus = dict(chest="chest", back="backMuscle", shoulders="ex:ohp", biceps="biceps", triceps="ex:pushdown", quads="ex:squat",
           hamstrings="ex:rdl", glutes="ex:thrust", calves="ex:calf", core="ex:plank", full="ex:burpee")
for s in slots:
    k = ex.get(s[3:]) if s.startswith("ex-") else mus.get(s[2:]) if s.startswith("m-") else s[2:]
    if s.startswith("ex-") and os.path.exists(D + s + ".jpg"): continue
    src = (D + "ex-" + k[3:] + ".jpg") if str(k).startswith("ex:") else I + f"{k}.jpg"
    shutil.copy(src if os.path.exists(src) else I + "hero.jpg", D + s + ".jpg")
print(len(slots), "photo slots seeded")
