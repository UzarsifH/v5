// ساخت APK انتشار؛ برای انتشار مایکت باید KEYSTORE_PATH و رمزهای امضای ثابت تنظیم شده باشند.
import { spawnSync } from "node:child_process";
import { existsSync } from "node:fs";
import path from "node:path";

const isWin = process.platform === "win32";
const run = (cmd, args, cwd = process.cwd()) => {
  const r = spawnSync(cmd, args, { cwd, stdio: "inherit", shell: isWin });
  if (r.status !== 0) {
    console.error(`\n✖ دستور «${cmd} ${args.join(" ")}» با خطا تمام شد.`);
    process.exit(r.status ?? 1);
  }
};

if (!existsSync("android")) {
  console.error("پوشه‌ی android هنوز ساخته نشده. اول این را اجرا کن:  npm run android:init");
  process.exit(1);
}

run("npm", ["run", "build"]);
run("npx", ["cap", "sync", "android"]);
if (!process.env.KEYSTORE_PATH) {
  console.error("\n✖ برای APK نهایی انتشار، KEYSTORE_PATH باید تنظیم شود. از کلید debug برای انتشار مایکت استفاده نکن.");
  process.exit(1);
}
run(isWin ? "gradlew.bat" : "./gradlew", ["assembleRelease", "--no-daemon"], "android");

const apk = path.join("android", "app", "build", "outputs", "apk", "release", "app-release.apk");
console.log(`\n✔ تمام شد. فایل APK اینجاست:\n  ${path.resolve(apk)}`);
