// دانلود عکس‌های واقعی Pexels در GitHub Actions (به tmp_raw/)؛ بعد scripts/process-photos.py آن‌ها را کم‌حجم و هماهنگ می‌کند
import fs from "node:fs";
import { PHOTOS } from "./photo-manifest.mjs";
fs.mkdirSync("tmp_raw", { recursive: true });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const cache = new Map(); let ok = 0, bad = 0;
for (const [slot, id] of Object.entries(PHOTOS)) {
  if (cache.has(id)) { fs.copyFileSync(cache.get(id), `tmp_raw/${slot}.jpg`); ok++; continue; }
  const url = `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&w=900`;
  let done = false;
  for (let t = 0; t < 3 && !done; t++) {
    try {
      const r = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0 ForjaBuild" }, signal: AbortSignal.timeout(40000) });
      const buf = Buffer.from(await r.arrayBuffer());
      if (r.ok && (r.headers.get("content-type") || "").startsWith("image/") && buf.length > 10000) {
        fs.writeFileSync(`tmp_raw/${slot}.jpg`, buf); cache.set(id, `tmp_raw/${slot}.jpg`); done = true;
      }
    } catch { await sleep(1500); }
  }
  console.log(done ? "✔" : "✖", slot, id); done ? ok++ : bad++;
}
const sum = `real photos: ${ok} downloaded, ${bad} failed (art fallback used)`;
console.log(sum);
if (process.env.GITHUB_STEP_SUMMARY) fs.appendFileSync(process.env.GITHUB_STEP_SUMMARY, `### ${sum}\n`);
