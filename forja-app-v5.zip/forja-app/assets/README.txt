generated in CI by scripts/make-art.py
