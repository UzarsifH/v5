# فُرجا — نسخه انتشار اندروید

فُرجا یک اپ React + Vite + Capacitor است. اطلاعات حساب، اشتراک، پرداخت، برنامه و پیشرفت دیگر داخل `localStorage` نگهداری نمی‌شوند و روی Supabase ذخیره می‌شوند؛ بنابراین کاربر بعد از حذف و نصب مجدد، با همان شماره و رمز می‌تواند اطلاعات و اشتراک فعالش را بازیابی کند.

## 1) راه‌اندازی Supabase

فایل `supabase/schema.sql` را یک‌بار کامل در SQL Editor پروژه Supabase اجرا کن.

این فایل:
- جدول کاربران، نشست‌ها، اشتراک‌ها، پرداخت‌ها، برنامه، ارزیابی، تمرین، وزن و نصب‌ها را می‌سازد.
- حساب مدیر `09392871492` را با رمز `yosef8913` به‌صورت hash‌شده ایجاد می‌کند.
- قیمت اولیه را 249000 و SKU را `M2` قرار می‌دهد.
- کلید عمومی مایکت و package `ir.forja.app` را تنظیم می‌کند.
- دسترسی مستقیم anon/authenticated به جداول را می‌بندد و فقط RPC امن اپ را باز می‌گذارد.

**پسورد PostgreSQL را داخل APK یا `.env` اپ قرار نده.** اپ فقط URL و Publishable Key را لازم دارد.

## 2) تنظیم کلید عمومی Supabase

برای build می‌توانی این دو متغیر را در محیط build قرار دهی:

```env
VITE_SUPABASE_URL=https://fmpkueeghxzleknsqlkt.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=...
```

اگر قرارشان ندهی، URL و publishable key پروژه فعلی به‌عنوان fallback وجود دارد. Publishable key برای قرار گرفتن در اپ طراحی شده؛ **Database password / service-role key نباید داخل APK باشد.**

## 3) پرداخت مایکت

تنظیمات فعلی:
- package: `ir.forja.app`
- SKU: `M2`
- حالت: live
- مدت اشتراک: 30 روز
- RSA public key: کلید عمومی‌ای که برای این اپ داده شده

کد بومی `MyketBillingPlugin` از سرویس مایکت استفاده می‌کند و رسید را با کلید عمومی بررسی می‌کند. بعد از آن سرور SKU، payload، purchase token و یکتا بودن رسید را کنترل می‌کند.

## 4) خطای Play Protect / APK

تصویر ارسالی مربوط به **Play Protect هنگام نصب APK خارج از فروشگاه** است و متن آن می‌گوید توسعه‌دهنده برای Play Protect ناشناخته است؛ این با «خرابی کد اپ» یکی نیست.

برای انتشار، این پروژه دیگر APK debug را به‌عنوان نسخه نهایی تولید نمی‌کند. باید همان keystore ثابت انتشار اپ را استفاده کنی. تغییر keystore بین نسخه‌ها می‌تواند باعث شود نسخه جدید روی نسخه قبلی نصب/آپدیت نشود و برای فروشگاه مشکل ایجاد کند.

در GitHub Actions این Secrets را تنظیم کن:
- `KEYSTORE_BASE64`
- `KEYSTORE_PASSWORD`
- `KEYSTORE_KEY_PASSWORD`
- `KEY_ALIAS`

بعد Workflow نسخه `Build Android Release` را اجرا کن. خروجی `app-release.apk` یک Release امضاشده است.

**اگر اپ قبلاً در مایکت با یک keystore دیگر ثبت شده، همان keystore قبلی را نگه دار؛ keystore جدید نساز.**

## 5) پنل مدیریت

با همین صفحه ورود اپ:
- شماره: `09392871492`
- رمز: `yosef8913`

وارد حساب مدیر می‌شوی و خودکار به `/admin` می‌روی.

پنل فعلی:
- تعداد کاربران
- تعداد نصب‌های ثبت‌شده
- خریدهای موفق
- خریدهای ناموفق
- اشتراک‌های فعال
- درآمد ثبت‌شده
- تغییر قیمت اشتراک
- اعطای اشتراک به شماره دلخواه برای تعداد روز مشخص
- لغو اشتراک
- فهرست کاربران و تاریخ انقضای اشتراک

رمز مدیر داخل TypeScript یا APK قرار نگرفته و در دیتابیس به‌صورت bcrypt hash ذخیره می‌شود.

## 6) اجرای پروژه

```bash
npm install
npm run typecheck
npm run build
```

برای ساخت پروژه Android:

```bash
npm run android:init
```

برای APK نهایی انتشار:

```bash
KEYSTORE_PATH=/path/to/forja-release.jks \
KEYSTORE_PASSWORD='...' \
KEYSTORE_KEY_PASSWORD='...' \
KEY_ALIAS='forja' \
npm run android:apk
```

در ویندوز همین متغیرها را از Environment تنظیم کن.

## نکته امنیتی

توکن مایکت و پسورد PostgreSQL را نباید در کد فرانت‌اند یا APK قرار داد. اگر توکن مایکت فعلی یک secret واقعی است و قبلاً جایی عمومی منتشر شده، از پنل مربوطه آن را rotate کن و مقدار جدید را فقط در محیط سرور نگه دار.

## رفع خطای `Could not find function public.forja_api(...)`
اگر پروژه قدیمی قبلاً روی Supabase اجرا شده، ابتدا `supabase/repair_forja_api.sql` را اجرا کنید، سپس **کل `supabase/schema.sql` اصلاح‌شده** را از اول تا آخر اجرا کنید. این نسخه امضای تابع را دقیقاً به `forja_api(jsonb,text,text,text,text)` تغییر داده و GRANT نیز با همین امضا انجام می‌شود.
