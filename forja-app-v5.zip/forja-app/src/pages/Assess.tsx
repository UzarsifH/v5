import { apiFetch } from "@/lib/api";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "@/lib/nav";
import { QUESTIONS } from "@/lib/questions";
import { RippleButton, useAuth } from "@/components/Providers";
import { faNum } from "@/lib/format";
import type { AssessmentAnswers } from "@/lib/types";

export default function AssessPage() {
  const { user, loading, refresh } = useAuth();
  const router = useRouter();
  const [i, setI] = useState(0);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [answers, setAnswers] = useState<Partial<AssessmentAnswers>>({
    height: 175,
    weight: 75,
    priority: [],
  });

  useEffect(() => {
    if (!loading && !user) router.replace("/login");
    if (!loading && user && !user.isPremium) router.replace("/subscribe");
  }, [loading, user, router]);

  const q = QUESTIONS[i];
  const pct = Math.round(((i + 1) / QUESTIONS.length) * 100);

  const canNext = useMemo(() => {
    if (!q) return false;
    if (q.kind === "number") return Boolean(answers[q.id]);
    if (q.kind === "multi") return (answers.priority || []).length > 0;
    return Boolean(answers[q.id as keyof AssessmentAnswers]);
  }, [q, answers]);

  async function finish() {
    setBusy(true);
    setError("");
    const res = await apiFetch("/api/assessment", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(answers),
    });
    const data = await res.json();
    setBusy(false);
    if (!data.ok) {
      setError(data.error || "خطا در ساخت برنامه");
      return;
    }
    await refresh();
    router.replace("/plan");
  }

  function next() {
    if (i === QUESTIONS.length - 1) {
      void finish();
      return;
    }
    setI(i + 1);
  }

  return (
    <div className="px-5 pt-10">
      <div className="flex items-center justify-between text-xs text-[var(--muted)]">
        <span>ارزیابی مربی</span>
        <span>
          {faNum(i + 1)} / {faNum(QUESTIONS.length)}
        </span>
      </div>
      <div className="progress-line mt-3">
        <span style={{ width: `${pct}%` }} />
      </div>
      <h1 className="fade-up mt-6 text-2xl font-extrabold leading-snug">{q.title}</h1>
      <p className="mt-2 text-sm leading-7 text-[var(--muted)]">{q.subtitle}</p>

      <div className="mt-6 space-y-2">
        {q.kind === "number" && (
          <div className="card p-5 text-center">
            <div className="text-5xl font-extrabold text-[var(--lime)]">
              {faNum(Number(answers[q.id] || q.defaultValue))}
            </div>
            <div className="mt-1 text-xs">{q.unit}</div>
            <input
              type="range"
              min={q.min}
              max={q.max}
              value={Number(answers[q.id] || q.defaultValue)}
              onChange={(e) => setAnswers((a) => ({ ...a, [q.id]: Number(e.target.value) }))}
              className="mt-5 w-full accent-[#c8f542]"
            />
          </div>
        )}
        {q.kind === "single" &&
          q.options.map((op) => (
            <button
              key={op.id}
              className={`option ${answers[q.id as keyof AssessmentAnswers] === op.id ? "on" : ""}`}
              onClick={() => setAnswers((a) => ({ ...a, [q.id]: op.id }))}
            >
              <div className="font-extrabold">{op.label}</div>
              {op.hint ? <div className="mt-1 text-[11px] text-white/40">{op.hint}</div> : null}
            </button>
          ))}
        {q.kind === "multi" &&
          q.options.map((op) => {
            const on = (answers.priority || []).includes(op.id);
            return (
              <button
                key={op.id}
                className={`option ${on ? "on" : ""}`}
                onClick={() =>
                  setAnswers((a) => {
                    const cur = new Set(a.priority || []);
                    if (cur.has(op.id)) cur.delete(op.id);
                    else cur.add(op.id);
                    return { ...a, priority: [...cur] };
                  })
                }
              >
                {op.label}
              </button>
            );
          })}
      </div>

      {error ? <p className="mt-3 text-sm text-[var(--danger)]">{error}</p> : null}

      <div className="mt-6 grid grid-cols-2 gap-2">
        <RippleButton className="btn-ghost" onClick={() => setI(Math.max(0, i - 1))}>
          قبلی
        </RippleButton>
        <RippleButton className="btn-lime" disabled={!canNext || busy} onClick={next}>
          {i === QUESTIONS.length - 1 ? (busy ? "در حال طراحی..." : "بساز برنامه را") : "بعدی"}
        </RippleButton>
      </div>
    </div>
  );
}
