import { apiFetch } from "@/lib/api";
import { useState } from "react";
import { useRouter } from "@/lib/nav";
import { IMG } from "@/lib/media";
import { RippleButton, useAuth } from "@/components/Providers";

export default function LoginPage() {
  const router = useRouter();
  const { refresh } = useAuth();
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit() {
    setBusy(true);
    setError("");
    const res = await apiFetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ phone, password }),
    });
    const data = await res.json();
    setBusy(false);
    if (!data.ok) {
      setError(data.error || "ورود ناموفق");
      return;
    }
    await refresh();
    router.replace(data.user?.role === "admin" ? "/admin" : "/home");
  }

  return (
    <div className="pb-8">
      <div className="auth-hero">
        <img src={IMG.hero} alt="" className="auth-hero-img" />
        <div className="auth-hero-fade" />
        <img src={IMG.logo} alt="" className="auth-logo pop" />
      </div>
      <div className="relative px-5 pt-2">
      <h1 className="mt-5 text-3xl font-extrabold">خوش اومدی آهن‌کُش</h1>
      <p className="mt-2 text-sm text-[var(--muted)]">با شماره و رمزت وارد فُرجا شو.</p>

      <div className="mt-8 space-y-3">
        <input className="field" inputMode="tel" placeholder="۰۹۱۲۱۲۳۴۵۶۷" value={phone} onChange={(e) => setPhone(e.target.value)} />
        <input className="field" type="password" placeholder="رمز عبور" value={password} onChange={(e) => setPassword(e.target.value)} />
        {error ? <p className="text-sm text-[var(--danger)]">{error}</p> : null}
        <RippleButton className="btn-lime btn-full" disabled={busy} onClick={() => void submit()}>
          {busy ? "در حال ورود..." : "ورود به باشگاه"}
        </RippleButton>
      </div>

      <button className="mt-6 w-full text-sm text-[var(--muted)]" onClick={() => router.push("/register")}>
        حساب نداری؟ <span className="text-[var(--lime)]">ثبت‌نام</span>
      </button>
      </div>
    </div>
  );
}
