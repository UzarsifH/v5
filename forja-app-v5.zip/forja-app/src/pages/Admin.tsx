import { useCallback, useEffect, useState } from "react";
import { apiFetch } from "@/lib/api";
import { RippleButton, useAuth } from "@/components/Providers";
import { useRouter } from "@/lib/nav";
import { formatToman, faNum } from "@/lib/format";

type Stats = {
  users: number;
  successfulPurchases: number;
  failedPurchases: number;
  installs: number;
  activeSubscriptions: number;
  revenue: number;
  monthlyPrice: number;
};
type AdminUser = { id: number; phone: string; name: string | null; premiumUntil: string | null };

export default function AdminPage() {
  const { user, loading } = useAuth();
  const router = useRouter();
  const [stats, setStats] = useState<Stats | null>(null);
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [price, setPrice] = useState("");
  const [phone, setPhone] = useState("");
  const [days, setDays] = useState("30");
  const [msg, setMsg] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    const r = await apiFetch("/api/admin/overview");
    const d = await r.json();
    if (!d.ok) { setError(d.error || "دسترسی رد شد"); return; }
    setStats(d.stats);
    setUsers(d.users || []);
    setPrice(String(d.stats.monthlyPrice));
  }, []);

  useEffect(() => {
    if (!loading && (!user || user.role !== "admin")) router.replace("/home");
  }, [loading, user, router]);

  useEffect(() => { if (!loading && user?.role === "admin") void load(); }, [loading, user, load]);

  async function action(path: string, body: Record<string, unknown>) {
    setBusy(true); setError(""); setMsg("");
    try {
      const r = await apiFetch(path, { method: "POST", body: JSON.stringify(body) });
      const d = await r.json();
      if (!d.ok) setError(d.error || "عملیات ناموفق");
      else { setMsg("با موفقیت انجام شد"); await load(); }
    } catch { setError("ارتباط با سرور برقرار نشد"); }
    finally { setBusy(false); }
  }

  if (loading || !user || user.role !== "admin") return null;

  return (
    <div className="px-5 pt-8 pb-10" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <p className="chip">پنل مدیریت</p>
          <h1 className="mt-2 text-3xl font-extrabold">کنترل فُرجا</h1>
        </div>
        <button className="text-sm text-white/50" onClick={() => router.replace("/home")}>خروج</button>
      </div>

      {stats && (
        <div className="mt-6 grid grid-cols-2 gap-3">
          <Stat title="کاربران" value={stats.users} />
          <Stat title="نصب‌ها" value={stats.installs} />
          <Stat title="خرید موفق" value={stats.successfulPurchases} />
          <Stat title="خرید ناموفق" value={stats.failedPurchases} />
          <Stat title="اشتراک فعال" value={stats.activeSubscriptions} />
          <Stat title="درآمد ثبت‌شده" value={formatToman(stats.revenue)} />
        </div>
      )}

      <section className="card mt-5 p-5">
        <h2 className="font-extrabold">قیمت اشتراک</h2>
        <p className="mt-1 text-xs text-[var(--muted)]">قیمت جدید از دفعه بعد از سرور خوانده می‌شود.</p>
        <input className="field mt-4" inputMode="numeric" value={price} onChange={e => setPrice(e.target.value.replace(/\D/g,""))} />
        <RippleButton className="btn-lime btn-full mt-3" disabled={busy} onClick={() => void action("/api/admin/price",{price:Number(price)})}>ذخیره قیمت</RippleButton>
      </section>

      <section className="card mt-4 p-5">
        <h2 className="font-extrabold">اعطای اشتراک</h2>
        <div className="mt-4 grid grid-cols-2 gap-2">
          <input className="field col-span-2" inputMode="tel" placeholder="شماره ۰۹..." value={phone} onChange={e=>setPhone(e.target.value)} />
          <input className="field" inputMode="numeric" placeholder="روز" value={days} onChange={e=>setDays(e.target.value.replace(/\D/g,""))} />
          <RippleButton className="btn-lime" disabled={busy || !phone} onClick={() => void action("/api/admin/grant",{phone,days:Number(days||30)})}>اعطا</RippleButton>
        </div>
        <RippleButton className="btn-ghost btn-full mt-3" disabled={busy || !phone} onClick={() => void action("/api/admin/revoke",{phone})}>لغو اشتراک شماره</RippleButton>
      </section>

      {msg ? <p className="mt-4 text-sm text-[var(--lime)]">{msg}</p> : null}
      {error ? <p className="mt-4 text-sm text-[var(--danger)]">{error}</p> : null}

      <section className="card mt-4 p-5">
        <h2 className="font-extrabold">آخرین کاربران</h2>
        <div className="mt-3 space-y-2">
          {users.map(u => (
            <div key={u.id} className="rounded-2xl border border-white/5 bg-white/[.03] p-3">
              <div className="flex justify-between gap-3">
                <span className="font-bold">{u.name || "بدون نام"}</span>
                <span dir="ltr" className="text-xs text-white/50">{u.phone}</span>
              </div>
              <p className="mt-1 text-[11px] text-white/40">
                {u.premiumUntil ? `اشتراک تا ${new Date(u.premiumUntil).toLocaleDateString("fa-IR")}` : "بدون اشتراک"}
              </p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function Stat({ title, value }: { title: string; value: number | string }) {
  return <div className="card p-4"><p className="text-[11px] text-white/45">{title}</p><p className="mt-1 text-xl font-extrabold text-[var(--lime)]">{typeof value==="number"?faNum(value):value}</p></div>;
}
