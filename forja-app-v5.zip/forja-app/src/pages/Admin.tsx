import { apiFetch } from "@/lib/api";
import { useCallback, useEffect, useState } from "react";
import { useRouter } from "@/lib/nav";
import { RippleButton, useAuth } from "@/components/Providers";
import { formatToman } from "@/lib/format";

type Stats = { installs: number; users: number; active_subs: number; success: number; failed: number; pending: number; revenue: number; price: number };
type U = { phone: string; name: string | null; premium_until: string | null; created_at: string; last_seen: string; is_admin: boolean };
type P = { id: number; phone: string | null; amount: number; status: string; source: string; error: string | null; created_at: string };

const fa = (n: number | string) => Number(n).toLocaleString("fa-IR");
const day = (s: string | null) => (s ? new Date(s).toLocaleDateString("fa-IR") : "—");
const STATUS: Record<string, string> = { success: "موفق", failed: "ناموفق", canceled: "لغو شده", pending: "در انتظار" };

async function call(path: string, body?: unknown) {
  const res = await apiFetch(path, body === undefined ? {} : { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  return (await res.json()) as Record<string, unknown> & { ok: boolean; error?: string };
}

export default function AdminPage() {
  const { user, loading, logout } = useAuth();
  const router = useRouter();
  const [stats, setStats] = useState<Stats | null>(null);
  const [users, setUsers] = useState<U[]>([]);
  const [pays, setPays] = useState<P[]>([]);
  const [q, setQ] = useState("");
  const [grantPhone, setGrantPhone] = useState("");
  const [grantDays, setGrantDays] = useState("30");
  const [price, setPrice] = useState("");
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    const d = await call("/api/admin/overview");
    if (!d.ok) return setMsg(d.error || "خطا در دریافت اطلاعات");
    setStats(d.stats as Stats);
    setUsers(d.users as U[]);
    setPays(d.payments as P[]);
    setPrice(String((d.stats as Stats).price));
  }, []);

  useEffect(() => {
    if (!loading && !user) router.replace("/login");
    if (user?.isAdmin) void load();
  }, [loading, user, router, load]);

  async function run(path: string, body: unknown, ok: string) {
    setBusy(true);
    setMsg("");
    const d = await call(path, body);
    setBusy(false);
    setMsg(d.ok ? ok : d.error || "خطا");
    if (d.ok) void load();
  }

  async function search() {
    const d = await call("/api/admin/users", { q });
    if (d.ok) setUsers(d.users as U[]);
  }

  if (loading) return <div className="p-6 text-sm text-[var(--muted)]">در حال بارگذاری...</div>;
  if (!user?.isAdmin)
    return (
      <div className="px-5 pt-16 text-center">
        <p className="text-lg font-extrabold">دسترسی ندارید</p>
        <p className="mt-2 text-sm text-[var(--muted)]">این بخش فقط برای ادمین است.</p>
        <RippleButton className="btn-ghost mt-6" onClick={() => router.replace("/home")}>
          بازگشت
        </RippleButton>
      </div>
    );

  const cards: [string, string | number, string][] = stats
    ? [
        ["نصب‌ها", fa(stats.installs), "#9be15d"],
        ["کاربران", fa(stats.users), "#6cb8ff"],
        ["اشتراک فعال", fa(stats.active_subs), "#c8f542"],
        ["خرید موفق", fa(stats.success), "#4ade80"],
        ["خرید ناموفق", fa(stats.failed), "#ff5d73"],
        ["در انتظار", fa(stats.pending), "#e7c36a"],
      ]
    : [];

  return (
    <div className="px-4 pb-10 pt-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold">پنل ادمین</h1>
          <p className="text-xs text-[var(--muted)]">{user.phone}</p>
        </div>
        <div className="flex gap-2">
          <button className="btn-ghost px-3 py-2 text-xs" onClick={() => void load()}>بروزرسانی</button>
          <button className="btn-ghost px-3 py-2 text-xs" onClick={() => router.replace("/home")}>خروج از پنل</button>
        </div>
      </div>

      {msg ? <p className="card mt-4 p-3 text-sm">{msg}</p> : null}

      <div className="mt-4 grid grid-cols-3 gap-2">
        {cards.map(([l, v, c]) => (
          <div key={l} className="card p-3 text-center">
            <p className="text-xl font-extrabold" style={{ color: c }}>{v}</p>
            <p className="mt-1 text-[11px] text-[var(--muted)]">{l}</p>
          </div>
        ))}
      </div>
      {stats ? <p className="card mt-2 p-3 text-center text-sm">درآمد ثبت‌شده: <b>{formatToman(stats.revenue)}</b></p> : null}

      <section className="card mt-4 p-4">
        <h2 className="font-extrabold">قیمت اشتراک ماهانه (تومان)</h2>
        <div className="mt-3 flex gap-2">
          <input className="field" inputMode="numeric" value={price} onChange={(e) => setPrice(e.target.value.replace(/\D/g, ""))} />
          <RippleButton className="btn-lime px-5" disabled={busy} onClick={() => void run("/api/admin/price", { amount: Number(price) }, "قیمت ذخیره شد")}>
            ثبت
          </RippleButton>
        </div>
        <p className="mt-2 text-[11px] leading-6 text-white/45">این قیمت داخل اپ نمایش داده می‌شود. مبلغ واقعی کسر‌شده از کاربر همان قیمت محصول داخل پنل مایکت است؛ آن را هم هم‌زمان عوض کن.</p>
      </section>

      <section className="card mt-4 p-4">
        <h2 className="font-extrabold">اعطای اشتراک به یک شماره</h2>
        <input className="field mt-3" inputMode="tel" placeholder="۰۹۱۲۱۲۳۴۵۶۷" value={grantPhone} onChange={(e) => setGrantPhone(e.target.value)} />
        <input className="field mt-2" inputMode="numeric" placeholder="تعداد روز" value={grantDays} onChange={(e) => setGrantDays(e.target.value.replace(/\D/g, ""))} />
        <div className="mt-3 grid grid-cols-2 gap-2">
          <RippleButton className="btn-lime" disabled={busy} onClick={() => void run("/api/admin/grant", { phone: grantPhone, days: Number(grantDays) }, "اشتراک فعال شد")}>
            فعال‌سازی
          </RippleButton>
          <RippleButton className="btn-ghost" disabled={busy} onClick={() => void run("/api/admin/revoke", { phone: grantPhone }, "اشتراک لغو شد")}>
            لغو اشتراک
          </RippleButton>
        </div>
        <p className="mt-2 text-[11px] text-white/45">کاربر باید قبلاً داخل اپ ثبت‌نام کرده باشد.</p>
      </section>

      <section className="card mt-4 p-4">
        <h2 className="font-extrabold">کاربران</h2>
        <div className="mt-3 flex gap-2">
          <input className="field" placeholder="جستجوی شماره یا نام" value={q} onChange={(e) => setQ(e.target.value)} />
          <button className="btn-ghost px-4" onClick={() => void search()}>بگرد</button>
        </div>
        <div className="mt-3 space-y-2">
          {users.map((u) => {
            const active = u.premium_until && new Date(u.premium_until).getTime() > Date.now();
            return (
              <button key={u.phone} className="flex w-full items-center justify-between rounded-2xl bg-white/5 px-3 py-2 text-right" onClick={() => setGrantPhone(u.phone)}>
                <span>
                  <span className="block text-sm font-bold">{u.name || "بدون نام"} {u.is_admin ? "· ادمین" : ""}</span>
                  <span className="block text-[11px] text-white/45" dir="ltr">{u.phone}</span>
                </span>
                <span className={`text-[11px] ${active ? "text-[#c8f542]" : "text-white/40"}`}>{active ? `تا ${day(u.premium_until)}` : "بدون اشتراک"}</span>
              </button>
            );
          })}
        </div>
      </section>

      <section className="card mt-4 p-4">
        <h2 className="font-extrabold">آخرین پرداخت‌ها</h2>
        <div className="mt-3 space-y-2">
          {pays.length === 0 ? <p className="text-xs text-white/40">هنوز پرداختی ثبت نشده.</p> : null}
          {pays.map((p) => (
            <div key={p.id} className="flex items-center justify-between rounded-2xl bg-white/5 px-3 py-2 text-xs">
              <span dir="ltr">{p.phone}</span>
              <span>{p.source === "admin" ? "هدیه ادمین" : formatToman(p.amount)}</span>
              <span className={p.status === "success" ? "text-[#4ade80]" : "text-[#ff5d73]"}>{STATUS[p.status] || p.status}</span>
            </div>
          ))}
        </div>
      </section>

      <button className="mt-6 w-full text-sm text-[var(--muted)]" onClick={() => void logout().then(() => router.replace("/login"))}>
        خروج از حساب
      </button>
    </div>
  );
}
