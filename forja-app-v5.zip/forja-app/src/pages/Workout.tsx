import { apiFetch } from "@/lib/api";
import { useEffect, useMemo, useRef, useState } from "react";
import { useParams, useRouter } from "@/lib/nav";
import { useAuth } from "@/components/Providers";
import { RippleButton } from "@/components/Providers";
import type { PlannedDay, WorkoutPlanData } from "@/lib/types";
import { faNum, formatDuration } from "@/lib/format";

export default function WorkoutPlayerPage() {
  const params = useParams<{ day: string }>();
  const router = useRouter();
  const { user, loading } = useAuth();
  const [day, setDay] = useState<PlannedDay | null>(null);
  const [planId, setPlanId] = useState(0);
  const [step, setStep] = useState<"ready" | "work" | "rest" | "done">("ready");
  const [exI, setExI] = useState(0);
  const [setI, setSetI] = useState(0);
  const [restLeft, setRestLeft] = useState(0);
  const [loaded, setLoaded] = useState(false);
  const startedRef = useRef(Date.now());
  const doneRef = useRef(0);
  const finishedRef = useRef(false);
  const [xp, setXp] = useState(0);
  const [doneCount, setDoneCount] = useState(0);
  const [skipCount, setSkipCount] = useState(0);

  useEffect(() => {
    if (!loading && !user) router.replace("/login");
  }, [loading, user, router]);

  useEffect(() => {
    setLoaded(false);
    void apiFetch("/api/plan")
      .then((r) => r.json())
      .then((d) => {
        if (params.day === "free") {
          setDay(d.freeSession ?? null);
          setPlanId(0);
        } else {
          const plan = (d.plan ?? null) as WorkoutPlanData | null;
          const idx = Number(params.day);
          setDay(plan?.days.find((x) => x.index === idx) ?? null);
          setPlanId(d.planId ?? 0);
        }
        startedRef.current = Date.now();
        setLoaded(true);
      })
      .catch(() => setLoaded(true));
  }, [params.day]);

  const ex = day?.exercises[exI];
  const totalSets = useMemo(() => day?.exercises.reduce((s, e) => s + e.sets, 0) ?? 0, [day]);

  useEffect(() => {
    if (step !== "rest") return;
    if (restLeft <= 0) {
      setStep("work");
      return;
    }
    const t = setTimeout(() => setRestLeft((x) => x - 1), 1000);
    return () => clearTimeout(t);
  }, [step, restLeft]);

  async function log(status: "completed" | "skipped") {
    if (!ex || !day) return;
    await apiFetch("/api/workout/log", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        planId,
        dayIndex: day.index,
        exerciseId: ex.id,
        status,
        setsDone: status === "completed" ? ex.sets : setI,
        durationSec: Math.round((Date.now() - startedRef.current) / 1000),
      }),
    });
  }

  async function finish(extraXp = 0) {
    if (!day || finishedRef.current) return;
    finishedRef.current = true;
    const durationSec = Math.round((Date.now() - startedRef.current) / 1000);
    // اصلاح باگ قدیمی: doneCount داخل state بود و آخرین حرکت در XP حساب نمی‌شد
    const gained = 80 + doneRef.current * 20 + extraXp;
    await apiFetch("/api/workout/log", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        planId,
        dayIndex: day.index,
        calories: day.calories,
        durationSec,
        xp: gained,
      }),
    });
    setXp(gained);
    setStep("done");
  }

  function completeSet() {
    if (!ex) return;
    if (setI + 1 >= ex.sets) {
      void log("completed");
      doneRef.current += 1;
      setDoneCount(doneRef.current);
      if (exI + 1 >= (day?.exercises.length ?? 0)) {
        void finish(40);
      } else {
        setExI(exI + 1);
        setSetI(0);
        setStep("work");
      }
      return;
    }
    setSetI(setI + 1);
    setRestLeft(ex.restSec || 45);
    setStep("rest");
  }

  function skipEx() {
    void log("skipped");
    setSkipCount((n) => n + 1);
    if (exI + 1 >= (day?.exercises.length ?? 0)) void finish();
    else {
      setExI(exI + 1);
      setSetI(0);
      setStep("work");
    }
  }

  if (!day) {
    if (loaded) {
      return (
        <div className="px-5 pt-16 text-center">
          <h1 className="text-2xl font-extrabold">این جلسه پیدا نشد</h1>
          <p className="mt-2 text-sm text-[var(--muted)]">برنامه‌ات عوض شده یا این روز وجود ندارد.</p>
          <RippleButton className="btn-lime btn-full mt-6" onClick={() => router.replace("/train")}>
            برگشت به تقویم تمرین
          </RippleButton>
        </div>
      );
    }
    return <div className="p-6 text-sm text-[var(--muted)]">در حال آماده‌سازی جلسه...</div>;
  }

  if (step === "ready") {
    return (
      <div className="px-5 pt-10">
        <p className="chip">جلسه زنده</p>
        <h1 className="mt-3 text-3xl font-extrabold">{day.title}</h1>
        <p className="mt-2 text-sm leading-7 text-[var(--muted)]">{day.coachNote}</p>
        <div className="card mt-5 p-4">
          <p className="text-xs text-[var(--gold)]">گرم‌کردن</p>
          <ul className="mt-2 space-y-1 text-sm">
            {day.warmup.map((w) => (
              <li key={w}>• {w}</li>
            ))}
          </ul>
        </div>
        {day.isRest ? (
          <div className="card mt-4 p-4">
            {day.cooldown.map((c) => (
              <p key={c} className="text-sm leading-7">• {c}</p>
            ))}
            <RippleButton className="btn-lime btn-full mt-4" onClick={() => void finish(60)}>
              ریکاوری انجام شد
            </RippleButton>
          </div>
        ) : (
          <RippleButton
            className="btn-lime btn-full mt-6"
            onClick={() => {
              startedRef.current = Date.now();
              setStep("work");
            }}
          >
            شروع تمرین
          </RippleButton>
        )}
        <button className="mt-4 w-full text-sm text-white/40" onClick={() => router.back()}>
          انصراف
        </button>
      </div>
    );
  }

  if (step === "done") {
    return (
      <div className="px-5 pt-16 text-center">
        <div className="pop text-6xl">آتش</div>
        <h1 className="mt-4 text-3xl font-extrabold">جلسه فورج شد</h1>
        <p className="mt-2 text-sm text-[var(--muted)]">
          {faNum(doneCount)} حرکت کامل · {faNum(skipCount)} رد شده · XP {faNum(xp)}
        </p>
        <div className="mt-6 grid grid-cols-2 gap-2">
          <div className="card p-4">
            <div className="text-xl font-extrabold text-[var(--lime)]">{faNum(day.calories)}</div>
            <div className="text-[10px] text-[var(--muted)]">کالری تخمینی</div>
          </div>
          <div className="card p-4">
            <div className="text-xl font-extrabold text-[var(--gold)]">{faNum(totalSets)}</div>
            <div className="text-[10px] text-[var(--muted)]">ست‌های برنامه</div>
          </div>
        </div>
        <RippleButton className="btn-lime btn-full mt-8" onClick={() => router.push("/progress")}>
          دیدن نتیجه
        </RippleButton>
        <button className="mt-3 w-full text-sm text-white/50" onClick={() => router.push("/train")}>
          تقویم تمرین
        </button>
      </div>
    );
  }

  if (step === "rest" && ex) {
    return (
      <div className="flex min-h-[80vh] flex-col items-center justify-center px-6 text-center">
        <p className="text-xs text-[var(--muted)]">استراحت بین ست</p>
        <div className="timer-ring mt-6 grid h-40 w-40 place-items-center rounded-full border-4 border-[var(--lime)] text-5xl font-extrabold">
          {faNum(restLeft)}
        </div>
        <p className="mt-4 text-sm">{ex.nameFa} · ست بعدی {faNum(setI + 1)}</p>
        <RippleButton className="btn-ghost mt-8" onClick={() => setRestLeft(0)}>
          رد کردن استراحت
        </RippleButton>
      </div>
    );
  }

  if (!ex) return null;

  return (
    <div className="pb-6">
      <div className="relative h-64">
        <img src={ex.image} alt={ex.nameFa} className="h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#07070a] to-transparent" />
        <button className="absolute top-6 right-4 rounded-full bg-black/40 px-3 py-1 text-xs" onClick={() => router.back()}>
          خروج
        </button>
        <div className="absolute bottom-4 right-4 left-4">
          <p className="text-[11px] text-[var(--lime)]">
            حرکت {faNum(exI + 1)} از {faNum(day.exercises.length)} · {ex.muscleFa}
          </p>
          <h1 className="text-2xl font-extrabold">{ex.nameFa}</h1>
          <p className="text-xs text-white/60">{ex.nameEn}</p>
        </div>
      </div>
      <div className="px-4">
        <div className="progress-line mt-2">
          <span style={{ width: `${((exI + setI / ex.sets) / day.exercises.length) * 100}%` }} />
        </div>
        <div className="mt-4 grid grid-cols-3 gap-2 text-center">
          <div className="card p-3">
            <div className="font-extrabold">{faNum(ex.sets)}</div>
            <div className="text-[10px] text-[var(--muted)]">ست</div>
          </div>
          <div className="card p-3">
            <div className="font-extrabold">{ex.reps}</div>
            <div className="text-[10px] text-[var(--muted)]">تکرار</div>
          </div>
          <div className="card p-3">
            <div className="font-extrabold">{faNum(ex.restSec)}s</div>
            <div className="text-[10px] text-[var(--muted)]">استراحت</div>
          </div>
        </div>
        <div className="mt-4 flex justify-center gap-2">
          {Array.from({ length: ex.sets }).map((_, i) => (
            <span
              key={i}
              className="h-3 w-8 rounded-full"
              style={{ background: i < setI ? "#c8f542" : i === setI ? "#ff5a1f" : "rgba(255,255,255,0.12)" }}
            />
          ))}
        </div>
        <p className="mt-4 text-sm leading-7 text-white/80">{ex.notes}</p>
        <ul className="mt-2 space-y-1 text-xs text-[var(--muted)]">
          {ex.instructions.map((x) => (
            <li key={x}>• {x}</li>
          ))}
        </ul>
        <p className="mt-3 text-xs text-[var(--gold)]">{ex.tip}</p>
        <div className="mt-6 grid grid-cols-2 gap-2">
          <RippleButton className="btn-ghost" onClick={skipEx}>
            رد کردن حرکت
          </RippleButton>
          <RippleButton className="btn-lime" onClick={completeSet}>
            ست {faNum(setI + 1)} انجام شد
          </RippleButton>
        </div>
        <p className="mt-3 text-center text-[10px] text-white/30">{formatDuration(0)} RPE {faNum(ex.rpe)}</p>
      </div>
    </div>
  );
}
