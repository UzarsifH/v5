import { apiFetch } from "@/lib/api";
import { useEffect, useState } from "react";
import { useRouter } from "@/lib/nav";
import { useAuth } from "@/components/Providers";
import { RippleButton } from "@/components/Providers";
import { faNum } from "@/lib/format";
import { IMG } from "@/lib/media";

type Stats = { xp: number; calories: number; workouts: number; exercises: number; level: number };
type Weight = { id: number; weight: number; createdAt: string };
type Badge = { id: number; code: string; title: string };

export default function ProgressPage() {
  const { user, loading } = useAuth();
  const router = useRouter();
  const [stats, setStats] = useState<Stats | null>(null);
  const [weights, setWeights] = useState<Weight[]>([]);
  const [badges, setBadges] = useState<Badge[]>([]);
  const [w, setW] = useState("75");
  const [err, setErr] = useState("");

  useEffect(() => {
    if (!loading && !user) router.replace("/login");
  }, [loading, user, router]);

  function load() {
    void apiFetch("/api/progress")
      .then((r) => r.json())
      .then((d) => {
        setStats(d.stats);
        setWeights(d.weights || []);
        setBadges(d.badges || []);
      });
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function addWeight() {
    const res = await apiFetch("/api/progress", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ weight: w }),
    });
    const data = await res.json();
    setErr(data.ok ? "" : data.error || "ثبت وزن ناموفق بود");
    load();
  }

  const maxW = Math.max(...weights.map((x) => x.weight), 1);

  return (
    <div className="px-4 pb-6 pt-8">
      <h1 className="text-2xl font-extrabold">نتیجه و پیشرفت</h1>
      <p className="mt-1 text-xs text-[var(--muted)]">بدن دروغ نمی‌گوید. عددها اینجاست.</p>

      <div className="relative mt-4 overflow-hidden rounded-3xl" style={{ height: 160 }}>
        <img src={IMG.results} alt="" className="h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent" />
        <div className="absolute bottom-4 right-4">
          <p className="text-xs text-[var(--lime)]">سطح {faNum(stats?.level ?? 1)}</p>
          <p className="text-xl font-extrabold">XP {faNum(stats?.xp ?? 0)}</p>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-3 gap-2">
        {[
          [stats?.workouts ?? 0, "جلسه"],
          [stats?.exercises ?? 0, "حرکت"],
          [stats?.calories ?? 0, "کالری"],
        ].map(([n, l]) => (
          <div key={String(l)} className="card p-3 text-center">
            <div className="text-lg font-extrabold text-[var(--lime)]">{faNum(n as number)}</div>
            <div className="text-[10px] text-[var(--muted)]">{l}</div>
          </div>
        ))}
      </div>

      <div className="card mt-5 p-4">
        <p className="text-sm font-bold">ثبت وزن</p>
        <div className="mt-3 flex gap-2">
          <input className="field" value={w} onChange={(e) => setW(e.target.value)} inputMode="decimal" />
          <RippleButton className="btn-lime" onClick={() => void addWeight()}>
            ثبت
          </RippleButton>
        </div>
        {err ? <p className="mt-2 text-xs text-[var(--danger)]">{err}</p> : null}
        <div className="mt-4 flex h-24 items-end gap-1">
          {weights.slice(0, 14).reverse().map((x) => (
            <div
              key={x.id}
              className="flex-1 rounded-t-md bg-[var(--lime)]"
              style={{ height: `${(x.weight / maxW) * 100}%`, opacity: 0.85 }}
              title={String(x.weight)}
            />
          ))}
          {weights.length === 0 && <p className="text-xs text-[var(--muted)]">هنوز وزنی ثبت نشده.</p>}
        </div>
      </div>

      <h3 className="mt-6 text-sm font-bold">مدال‌ها</h3>
      <div className="mt-2 grid grid-cols-2 gap-2">
        {badges.length === 0 && <p className="text-xs text-[var(--muted)]">اولین جلسه را تمام کن تا مدال باز شود.</p>}
        {badges.map((b) => (
          <div key={b.id} className="card p-3">
            <div className="text-sm font-extrabold text-[var(--gold)]">{b.title}</div>
            <div className="text-[10px] text-white/40">{b.code}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
