import { apiFetch } from "@/lib/api";
import { useEffect, useState } from "react";
import { useRouter } from "@/lib/nav";
import { RippleButton, useAuth } from "@/components/Providers";
import { faNum, formatToman } from "@/lib/format";
import { IMG } from "@/lib/media";

type Pay = { id: number; amount: number; status: string; createdAt: string; orderId: string | null };
type Sub = { id: number; status: string; amount: number; expiresAt: string | null };

export default function ProfilePage() {
  const { user, loading, logout, refresh } = useAuth();
  const router = useRouter();
  const [name, setName] = useState("");
  const [msg, setMsg] = useState("");
  const [pays, setPays] = useState<Pay[]>([]);
  const [subs, setSubs] = useState<Sub[]>([]);

  useEffect(() => {
    if (!loading && !user) router.replace("/login");
  }, [loading, user, router]);

  useEffect(() => {
    if (user?.name) setName(user.name);
    void apiFetch("/api/profile")
      .then((r) => r.json())
      .then((d) => {
        setPays(d.payments || []);
        setSubs(d.subscriptions || []);
      });
  }, [user]);

  async function save() {
    const res = await apiFetch("/api/profile", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name }),
    });
    const data = await res.json();
    setMsg(data.ok ? "ذخیره شد ✓" : data.error || "ذخیره نشد");
    setTimeout(() => setMsg(""), 2200);
    await refresh();
  }

  if (!user) return null;

  return (
    <div className="px-4 pb-8 pt-8">
      <div className="flex items-center gap-3">
        <img src={IMG.coach} alt="" className="h-16 w-16 rounded-3xl object-cover" />
        <div>
          <h1 className="text-xl font-extrabold">{user.name || "بدون نام"}</h1>
          <p className="text-xs text-[var(--muted)]">{user.phone}</p>
        </div>
      </div>

      <div className="card mt-5 p-4">
        <p className="text-xs text-[var(--muted)]">نام نمایشی</p>
        <input className="field mt-2" value={name} onChange={(e) => setName(e.target.value)} />
        <RippleButton className="btn-ghost mt-3 w-full" onClick={() => void save()}>
          ذخیره پروفایل
        </RippleButton>
        {msg ? <p className="mt-2 text-center text-xs text-[var(--lime)]">{msg}</p> : null}
      </div>

      <div className="card mt-4 p-4">
        <p className="text-sm font-bold">اشتراک</p>
        {user.isPremium ? (
          <p className="mt-2 text-sm text-[var(--lime)]">
            فعال تا {user.premiumUntil ? faNum(new Date(user.premiumUntil).toLocaleDateString("fa-IR")) : "—"}
          </p>
        ) : (
          <div className="mt-2">
            <p className="text-xs text-[var(--muted)]">هنوز اشتراک نداری. می‌تونی آزاد بگردی و وقتی آماده بودی مربی کامل را باز کنی.</p>
            <RippleButton className="btn-lime mt-3 w-full" onClick={() => router.push("/subscribe")}>
              دیدن اشتراک ماهانه
            </RippleButton>
          </div>
        )}
        {subs.map((s) => (
          <div key={s.id} className="mt-2 text-xs text-white/50">
            {s.status} · {formatToman(s.amount)}
          </div>
        ))}
      </div>

      <h3 className="mt-6 text-sm font-bold">تاریخچه خرید</h3>
      <div className="mt-2 space-y-2">
        {pays.length === 0 && <p className="text-xs text-[var(--muted)]">خریدی ثبت نشده.</p>}
        {pays.map((p) => (
          <div key={p.id} className="card flex items-center justify-between p-3">
            <div>
              <div className="text-sm font-bold">{formatToman(p.amount)}</div>
              <div className="text-[10px] text-white/40">{p.orderId || "مایکت"}</div>
            </div>
            <span className={`text-xs ${p.status === "paid" ? "text-[var(--lime)]" : "text-[var(--gold)]"}`}>
              {p.status === "paid" ? "موفق" : p.status === "pending" ? "در انتظار" : p.status}
            </span>
          </div>
        ))}
      </div>

      <button
        className="mt-8 w-full text-sm text-[var(--danger)]"
        onClick={async () => {
          await logout();
          router.replace("/login");
        }}
      >
        خروج از حساب
      </button>
    </div>
  );
}
