/**
 * جایگزین next/navigation برای react-router
 * (همان API: useRouter().push / replace / back ، usePathname ، useParams)
 */
import { useMemo } from "react";
import { useLocation, useNavigate, useParams as useRouterParams } from "react-router-dom";

export function useRouter() {
  const navigate = useNavigate();
  return useMemo(
    () => ({
      push: (to: string) => navigate(to),
      replace: (to: string) => navigate(to, { replace: true }),
      back: () => {
        const idx = (window.history.state as { idx?: number } | null)?.idx ?? 0;
        if (idx > 0) navigate(-1);
        else navigate("/home", { replace: true });
      },
    }),
    [navigate],
  );
}

export function usePathname() {
  return useLocation().pathname;
}

export const useParams = useRouterParams;
