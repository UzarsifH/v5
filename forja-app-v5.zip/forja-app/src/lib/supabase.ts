const SUPABASE_URL =
  import.meta.env.VITE_SUPABASE_URL || "https://fmpkueeghxzleknsqlkt.supabase.co";
const SUPABASE_KEY =
  import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY ||
  "sb_publishable_zq2wk9CLunDukELjHwTLQw_mObMnE7v";

const TOKEN_KEY = "forja_session_token";
const INSTALL_KEY = "forja_install_id";

function ensureInstallId() {
  let id = "";
  try { id = localStorage.getItem(INSTALL_KEY) || ""; } catch {}
  if (!id) {
    const c = globalThis.crypto;
    id = c?.randomUUID ? c.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    try { localStorage.setItem(INSTALL_KEY, id); } catch {}
  }
  return id;
}

export function getSessionToken() {
  try { return localStorage.getItem(TOKEN_KEY); } catch { return null; }
}
export function setSessionToken(token: string | null) {
  try {
    if (token) localStorage.setItem(TOKEN_KEY, token);
    else localStorage.removeItem(TOKEN_KEY);
  } catch {}
}
export function getInstallId() { return ensureInstallId(); }

export async function supabaseRpc(name: string, args: Record<string, unknown> = {}) {
  const token = getSessionToken();
  const res = await fetch(`${SUPABASE_URL}/rest/v1/rpc/${name}`, {
    method: "POST",
    headers: {
      apikey: SUPABASE_KEY,
      Authorization: `Bearer ${SUPABASE_KEY}`,
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify({
      ...args,
      p_token: token,
      p_install_id: ensureInstallId(),
    }),
  });
  let data: unknown = null;
  try { data = await res.json(); } catch {}
  if (!res.ok) throw new Error((data as { message?: string })?.message || "ارتباط با سرور برقرار نشد");
  return data as Record<string, unknown>;
}
