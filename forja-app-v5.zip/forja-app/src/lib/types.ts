export type Muscle =
  | "chest"
  | "back"
  | "shoulders"
  | "biceps"
  | "triceps"
  | "quads"
  | "hamstrings"
  | "glutes"
  | "calves"
  | "core"
  | "full";

export type Equipment = "gym" | "dumbbell" | "bodyweight" | "band";
export type Level = "beginner" | "intermediate" | "advanced";
export type Injury = "none" | "knee" | "back" | "shoulder" | "wrist";

export type Exercise = {
  id: string;
  nameFa: string;
  nameEn: string;
  muscle: Muscle;
  secondary: Muscle[];
  equipment: Equipment[];
  level: Level;
  avoid: Injury[];
  instructions: string[];
  tip: string;
  image: string;
  caloriesPerMin: number;
  defaultSets: number;
  defaultReps: string;
  restSec: number;
};

export type PlannedExercise = {
  id: string;
  nameFa: string;
  nameEn: string;
  muscle: string;
  muscleFa: string;
  image: string;
  sets: number;
  reps: string;
  restSec: number;
  rpe: number;
  notes: string;
  instructions: string[];
  tip: string;
};

export type PlannedDay = {
  index: number;
  week: number;
  title: string;
  focus: string;
  isRest: boolean;
  durationMin: number;
  calories: number;
  coachNote: string;
  warmup: string[];
  exercises: PlannedExercise[];
  cooldown: string[];
};

export type WorkoutPlanData = {
  title: string;
  subtitle: string;
  weeks: number;
  daysPerWeek: number;
  split: string;
  goal: string;
  goalFa: string;
  bmi: number;
  bmiLabel: string;
  height: number;
  weight: number;
  estimatedChange: string;
  nutritionTips: string[];
  rules: string[];
  days: PlannedDay[];
  createdAt: string;
};

export type AssessmentAnswers = {
  gender: string;
  age: string;
  height: number;
  weight: number;
  goal: string;
  experience: string;
  days: string;
  duration: string;
  focus: string;
  priority: string[];
  equipment: string;
  injury: string;
  style: string;
  intensity: string;
  activity: string;
  sleep: string;
  cardio: string;
  weak: string;
};

export type MeUser = {
  id: number;
  phone: string;
  name: string | null;
  createdAt: string;
  isPremium: boolean;
  premiumUntil: string | null;
  hasPlan: boolean;
  hasAssessment: boolean;
  isAdmin?: boolean;
};

export type SettingMap = {
  monthly_price: string;
  payment_mode: string;
  myket_package_name: string;
  myket_rsa_public_key: string;
  myket_sku_monthly: string;
  myket_access_token: string;
  app_name: string;
};
