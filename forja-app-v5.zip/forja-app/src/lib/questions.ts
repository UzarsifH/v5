export type Option = { id: string; label: string; hint?: string };

export type Question =
  | {
      id: "height" | "weight";
      title: string;
      subtitle: string;
      kind: "number";
      min: number;
      max: number;
      unit: string;
      defaultValue: number;
    }
  | {
      id: string;
      title: string;
      subtitle: string;
      kind: "single";
      options: Option[];
    }
  | {
      id: string;
      title: string;
      subtitle: string;
      kind: "multi";
      options: Option[];
    };

export const QUESTIONS: Question[] = [
  {
    id: "gender",
    title: "جنسیتت چیه؟",
    subtitle: "برنامه و حجم تمرین بر اساس ساختار بدنی تنظیم می‌شه.",
    kind: "single",
    options: [
      { id: "male", label: "مرد", hint: "تمرکز روی قدرت و حجم" },
      { id: "female", label: "زن", hint: "تمرکز روی فرم و قدرت" },
    ],
  },
  {
    id: "age",
    title: "حدود سنت چقدره؟",
    subtitle: "ریکاوری و شدت تمرین با سن هماهنگ می‌شه.",
    kind: "single",
    options: [
      { id: "u18", label: "زیر ۱۸" },
      { id: "18-25", label: "۱۸ تا ۲۵" },
      { id: "26-35", label: "۲۶ تا ۳۵" },
      { id: "36-45", label: "۳۶ تا ۴۵" },
      { id: "46-55", label: "۴۶ تا ۵۵" },
      { id: "55p", label: "بالای ۵۵" },
    ],
  },
  {
    id: "height",
    title: "قدت چند سانته؟",
    subtitle: "برای محاسبه BMI و حجم تمرین لازمه.",
    kind: "number",
    min: 140,
    max: 210,
    unit: "سانتی‌متر",
    defaultValue: 175,
  },
  {
    id: "weight",
    title: "وزنت چند کیلوئه؟",
    subtitle: "نقطه شروع مربی برای طراحی برنامه.",
    kind: "number",
    min: 40,
    max: 160,
    unit: "کیلوگرم",
    defaultValue: 75,
  },
  {
    id: "goal",
    title: "هدف اصلیت چیه؟",
    subtitle: "کل ساختار برنامه روی همین هدف سوار می‌شه.",
    kind: "single",
    options: [
      { id: "fatloss", label: "چربی‌سوزی", hint: "کاهش وزن با حفظ عضله" },
      { id: "muscle", label: "عضله‌سازی", hint: "هایپرتروفی و حجم" },
      { id: "strength", label: "قدرت", hint: "رکورد و وزنه‌های سنگین" },
      { id: "recomp", label: "فرم‌دهی", hint: "هم عضله هم چربی‌سوزی" },
      { id: "endurance", label: "استقامت", hint: "توان و نفس" },
    ],
  },
  {
    id: "experience",
    title: "سطح تجربه‌ت؟",
    subtitle: "حجم، تکنیک و شدت با سطح تو مچ می‌شه.",
    kind: "single",
    options: [
      { id: "beginner", label: "مبتدی", hint: "کمتر از ۶ ماه" },
      { id: "intermediate", label: "متوسط", hint: "۶ ماه تا ۲ سال" },
      { id: "advanced", label: "پیشرفته", hint: "بیشتر از ۲ سال" },
    ],
  },
  {
    id: "days",
    title: "هفته‌ای چند روز می‌تونی تمرین کنی؟",
    subtitle: "اسپلیت تمرینی دقیق بر اساس همین عدد چیده می‌شه.",
    kind: "single",
    options: [
      { id: "3", label: "۳ روز" },
      { id: "4", label: "۴ روز" },
      { id: "5", label: "۵ روز" },
      { id: "6", label: "۶ روز" },
    ],
  },
  {
    id: "duration",
    title: "هر جلسه چقدر زمان داری؟",
    subtitle: "تعداد حرکت‌ها و ست‌ها با زمانت تنظیم می‌شه.",
    kind: "single",
    options: [
      { id: "30", label: "۳۰ دقیقه" },
      { id: "45", label: "۴۵ دقیقه" },
      { id: "60", label: "۶۰ دقیقه" },
      { id: "90", label: "۹۰ دقیقه" },
    ],
  },
  {
    id: "focus",
    title: "بیشتر روی کدوم بخش بدن کار کنیم؟",
    subtitle: "حجم تمرین همون بخش بالاتر می‌ره، بقیه حفظ می‌شه.",
    kind: "single",
    options: [
      { id: "full", label: "کل بدن", hint: "تعادل کامل" },
      { id: "upper", label: "بالاتنه", hint: "سینه، پشت، شانه، بازو" },
      { id: "lower", label: "پایین‌تنه", hint: "ران، باسن، ساق" },
      { id: "push", label: "پرس‌محور", hint: "سینه و شانه و پشت‌بازو" },
      { id: "core", label: "میان‌تنه و فرم", hint: "شکم و کمر" },
    ],
  },
  {
    id: "priority",
    title: "کدوم عضله‌ها برات اولویت دارن؟",
    subtitle: "می‌تونی چندتا انتخاب کنی. مربی حجمشون رو بیشتر می‌کنه.",
    kind: "multi",
    options: [
      { id: "chest", label: "سینه" },
      { id: "back", label: "زیربغل / پشت" },
      { id: "shoulders", label: "شانه" },
      { id: "arms", label: "بازو" },
      { id: "glutes", label: "باسن" },
      { id: "quads", label: "جلو ران" },
      { id: "hamstrings", label: "پشت ران" },
      { id: "core", label: "شکم" },
    ],
  },
  {
    id: "equipment",
    title: "با چه وسایلی تمرین می‌کنی؟",
    subtitle: "حرکت‌ها فقط از همین تجهیزات انتخاب می‌شن.",
    kind: "single",
    options: [
      { id: "gym", label: "باشگاه کامل", hint: "دستگاه + هالتر + دمبل" },
      { id: "dumbbell", label: "دمبل در خانه" },
      { id: "bodyweight", label: "وزن بدن" },
      { id: "band", label: "کش مقاومتی" },
    ],
  },
  {
    id: "injury",
    title: "آسیب یا محدودیت داری؟",
    subtitle: "حرکت‌های پرخطر برای اون ناحیه حذف می‌شن.",
    kind: "single",
    options: [
      { id: "none", label: "ندارم" },
      { id: "knee", label: "زانو" },
      { id: "back", label: "کمر" },
      { id: "shoulder", label: "شانه" },
      { id: "wrist", label: "مچ" },
    ],
  },
  {
    id: "style",
    title: "سبک تمرین مورد علاقه‌ت؟",
    subtitle: "ست و تکرار و ریتم جلسه با این انتخاب عوض می‌شه.",
    kind: "single",
    options: [
      { id: "hypertrophy", label: "حجم‌سازی کلاسیک" },
      { id: "strength", label: "قدرتی" },
      { id: "circuit", label: "سیرکیت و عرق‌ریز" },
      { id: "mixed", label: "ترکیبی" },
    ],
  },
  {
    id: "intensity",
    title: "چقدر سخت تمرین کنیم؟",
    subtitle: "RPE و اضافه بار هفته‌به‌هفته از اینجا می‌آد.",
    kind: "single",
    options: [
      { id: "easy", label: "آرام و پایدار" },
      { id: "moderate", label: "متوسط و جدی" },
      { id: "hardcore", label: "سخت و حرفه‌ای" },
    ],
  },
  {
    id: "activity",
    title: "بقیه روز چقدر فعالی؟",
    subtitle: "کالری و کاردیو با سبک زندگی‌ت هماهنگ می‌شه.",
    kind: "single",
    options: [
      { id: "sedentary", label: "کاملاً پشت‌میز" },
      { id: "light", label: "کمی پیاده" },
      { id: "moderate", label: "فعال" },
      { id: "high", label: "خیلی فعال" },
    ],
  },
  {
    id: "sleep",
    title: "شب‌ها معمولاً چند ساعت می‌خوابی؟",
    subtitle: "ریکاوری یعنی رشد. حجم تمرین با خواب تنظیم می‌شه.",
    kind: "single",
    options: [
      { id: "low", label: "کمتر از ۶ ساعت" },
      { id: "ok", label: "۶ تا ۷ ساعت" },
      { id: "good", label: "۷ تا ۸ ساعت" },
      { id: "great", label: "بیشتر از ۸ ساعت" },
    ],
  },
  {
    id: "cardio",
    title: "کاردیو داخل برنامه باشه؟",
    subtitle: "بسته به هدفت مقدارش فرق می‌کنه.",
    kind: "single",
    options: [
      { id: "yes", label: "بله، حتماً" },
      { id: "light", label: "کم و هوشمند" },
      { id: "no", label: "نه، فقط وزنه" },
    ],
  },
  {
    id: "weak",
    title: "نقطه ضعفت کدومه؟",
    subtitle: "مربی اول جلسه یا آخر جلسه روش کار می‌ذاره.",
    kind: "single",
    options: [
      { id: "chest", label: "سینه ضعیف" },
      { id: "back", label: "پشت ضعیف" },
      { id: "legs", label: "پا ضعیف" },
      { id: "arms", label: "بازو نازک" },
      { id: "core", label: "شکم شل" },
      { id: "posture", label: "قوز و فرم بد" },
      { id: "none", label: "نقطه ضعف خاصی ندارم" },
    ],
  },
];
