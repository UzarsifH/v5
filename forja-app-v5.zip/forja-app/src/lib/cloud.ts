/** اتصال به Supabase: حساب کاربری، اشتراک، پرداخت‌ها و پنل ادمین (کلید عمومی publishable ایمن است؛ امنیت با RLS سمت سرور است) */
import { createClient } from "@supabase/supabase-js";
import { Capacitor } from "@capacitor/core";
import { APP_CONFIG } from "@/config";
import { getDb, setSaveHook } from "@/lib/db";

export const sb = createClient(APP_CONFIG.supabaseUrl, APP_CONFIG.supabaseKey, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: false },
});

export const phoneToEmail = (phone: string) => `${phone}@forja.app`;

export type CloudProfile = {
  id: string;
  phone: string;
  name: string | null;
  is_admin: boolean;
  premium_until: string | null;
  data: Record<string, unknown> | null;
};

export async function cloudProfile(): Promise<CloudProfile | null> {
  const { data: s } = await sb.auth.getSession();
  if (!s.session) return null;
  const { data, error } = await sb.from("profiles").select("*").eq("id", s.session.user.id).maybeSingle();
  if (error) throw error;
  return (data as CloudProfile | null) ?? null;
}

/** درخواست‌های Supabase تنبل هستند؛ این تابع مطمئن می‌شود واقعاً ارسال شوند */
export function fire(q: PromiseLike<unknown>) {
  void Promise.resolve(q).catch(() => {});
}

export function trackInstall() {
  try {
    let id = localStorage.getItem("forja_device");
    if (!id) {
      id = crypto.randomUUID();
      localStorage.setItem("forja_device", id);
    }
    fire(sb.rpc("track_install", { p_device: id, p_platform: Capacitor.getPlatform() }));
  } catch {
    /* ignore */
  }
}

const MAP: Record<string, string> = {
  "Invalid login credentials": "شماره یا رمز اشتباه است",
  "User already registered": "این شماره قبلاً ثبت شده. وارد شو.",
  token_used: "این رسید قبلاً استفاده شده",
  sku_mismatch: "محصول خریداری‌شده با محصول اپ یکی نیست",
  payload_mismatch: "رسید مربوط به این پرداخت نیست",
  package_mismatch: "رسید مربوط به این اپ نیست",
  not_purchased: "پرداخت کامل نشده",
  not_authenticated: "دوباره وارد حساب شو",
  forbidden: "دسترسی ادمین نداری",
  user_not_found: "کاربری با این شماره پیدا نشد",
  bad_days: "تعداد روز معتبر نیست",
  bad_price: "قیمت معتبر نیست",
};

export function cloudErr(e: unknown): string {
  const m = e instanceof Error ? e.message : typeof e === "object" && e && "message" in e ? String((e as { message: unknown }).message) : String(e);
  for (const k of Object.keys(MAP)) if (m.includes(k)) return MAP[k];
  if (/fetch|network|timeout|Load failed/i.test(m)) return "اینترنت لازم است؛ اتصالت رو چک کن و دوباره تلاش کن.";
  if (/rate limit/i.test(m)) return "تعداد تلاش زیاد بود؛ چند دقیقه دیگه دوباره امتحان کن.";
  return m || "خطای غیرمنتظره. دوباره تلاش کن.";
}

/* ───── همگام‌سازی اطلاعات کاربر با سرور (برنامه، تمرین‌ها، وزن‌ها...) ───── */
let timer: ReturnType<typeof setTimeout> | null = null;
let syncing = false;

export function snapshot() {
  const db = getDb();
  return {
    seq: db.seq,
    assessments: db.assessments,
    workoutPlans: db.workoutPlans,
    workoutLogs: db.workoutLogs,
    dayCompletions: db.dayCompletions,
    weightLogs: db.weightLogs,
    achievements: db.achievements,
  };
}

export async function pushNow() {
  const { data: s } = await sb.auth.getSession();
  if (!s.session) return;
  await sb.from("profiles").update({ data: snapshot(), last_seen: new Date().toISOString() }).eq("id", s.session.user.id);
}

export function syncSoon() {
  if (timer) clearTimeout(timer);
  timer = setTimeout(() => {
    if (syncing) return syncSoon();
    syncing = true;
    pushNow().catch(() => {}).finally(() => (syncing = false));
  }, 1500);
}

export function startSync() {
  setSaveHook(syncSoon);
}
export function stopSync() {
  setSaveHook(null);
  if (timer) clearTimeout(timer);
}
