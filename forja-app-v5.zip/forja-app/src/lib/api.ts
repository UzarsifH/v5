/**
 * API ریموت فُرجا.
 * داده‌های حساب، اشتراک، پرداخت، برنامه و پیشرفت روی Supabase ذخیره می‌شوند
 * و بعد از حذف/نصب دوباره اپ با ورود مجدد قابل بازیابی‌اند.
 */
import { generatePlan, FREE_SESSION } from "@/lib/coach";
import { EXERCISES } from "@/lib/exercises";
import { supabaseRpc, getSessionToken, setSessionToken } from "@/lib/supabase";
import type { MyketPurchase } from "@/lib/myket";
import type { AssessmentAnswers, MeUser } from "@/lib/types";

type Json = Record<string, unknown>;
type Body = Record<string, unknown> | null;

function response(data: Json, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

function normalizeResult(result: Record<string, unknown>) {
  // SQL function returns {ok:true,...} or {ok:false,error:...}
  return result;
}

export async function apiFetch(input: string, init: { method?: string; body?: string | null; headers?: Record<string, string> } = {}) {
  const method = (init.method || "GET").toUpperCase();
  const path = input.split("?")[0].replace(/^\/api/, "");
  let body: Body = null;
  if (init.body) {
    try { body = JSON.parse(init.body) as Body; } catch { body = null; }
  }

  try {
    let result: Record<string, unknown>;

    // Public/local exercise catalogue does not need a DB round-trip.
    if (method === "GET" && path === "/exercises") {
      return response({
        ok: true,
        exercises: EXERCISES.map((e) => ({
          id: e.id, nameFa: e.nameFa, nameEn: e.nameEn, muscle: e.muscle,
          level: e.level, image: e.image, equipment: e.equipment,
          instructions: e.instructions, tip: e.tip,
        })),
      });
    }

    // /auth/login and /auth/register return a new session token.
    result = await supabaseRpc("forja_api", {
      p_path: path,
      p_method: method,
      p_body: body,
    });

    if (result.token && typeof result.token === "string") setSessionToken(result.token);
    if (path === "/auth/logout") setSessionToken(null);
    if (path === "/plan" && result.ok !== false) result.freeSession = FREE_SESSION;

    return response(normalizeResult(result), result.ok === false ? 400 : 200);
  } catch (e) {
    console.error("[forja]", e);
    return response({ ok: false, error: e instanceof Error ? e.message : "ارتباط با سرور برقرار نشد" }, 503);
  }
}

export { getSessionToken };

export function makeAssessmentPlan(answers: AssessmentAnswers) {
  return generatePlan(answers);
}

export { FREE_SESSION };

export type { MeUser, AssessmentAnswers, MyketPurchase };
