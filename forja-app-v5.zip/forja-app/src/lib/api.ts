/**
 * جایگزین سرور قبلی (Next.js API + PostgreSQL).
 * `apiFetch` همان شکل `fetch` را دارد و همان خروجی‌ها را می‌دهد،
 * اما همه‌چیز را روی خود گوشی انجام می‌دهد؛ بنابراین اپ بدون اینترنت و بدون سرور کار می‌کند.
 */
import { APP_CONFIG } from "@/config";
import { FREE_SESSION, generatePlan } from "@/lib/coach";
import { getDb, nextId, nowIso, resetDb, saveDb, type DB, type UserRow } from "@/lib/db";
import { cloudErr, cloudProfile, phoneToEmail, pushNow, sb, startSync, stopSync, type CloudProfile } from "@/lib/cloud";
import { EXERCISES } from "@/lib/exercises";
import type { MyketPurchase } from "@/lib/myket";
import type { AssessmentAnswers, MeUser } from "@/lib/types";
import { bmiOf, isValidPhone, normalizePhone } from "@/lib/utils";

type Json = Record<string, unknown>;
type Body = Record<string, unknown> | null;
type Handler = (body: Body) => Promise<Json> | Json;

class HttpError extends Error {
  status: number;
  constructor(message: string, status = 400) {
    super(message);
    this.status = status;
  }
}

const fail = (message: string, status = 400): never => {
  throw new HttpError(message, status);
};

/* ───────────── کمکی‌ها ───────────── */

let cloudMe: CloudProfile | null = null;

function toMe(db: DB, user: UserRow): MeUser {
  const until = cloudMe?.premium_until ?? null;
  const active = until && new Date(until).getTime() > Date.now() ? { expiresAt: until } : null;
  return {
    isAdmin: Boolean(cloudMe?.is_admin),
    id: user.id,
    phone: user.phone,
    name: user.name,
    createdAt: user.createdAt,
    isPremium: Boolean(active),
    premiumUntil: active?.expiresAt ?? null,
    hasPlan: db.workoutPlans.some((p) => p.userId === user.id),
    hasAssessment: db.assessments.some((a) => a.userId === user.id),
  };
}

function currentUser(db: DB): UserRow | null {
  if (db.currentUserId == null) return null;
  return db.users.find((u) => u.id === db.currentUserId) ?? null;
}

function requireUser(db: DB): { row: UserRow; me: MeUser } {
  const row = currentUser(db);
  if (!row) return fail("وارد حساب شو", 401);
  return { row, me: toMe(db, row) };
}


/** بعد از ورود: اطلاعات ذخیره‌شده روی سرور را داخل دیتابیس گوشی می‌ریزد */
function hydrate(p: CloudProfile) {
  cloudMe = p;
  const db = resetDb();
  const row: UserRow = { id: 1, phone: p.phone, passwordHash: "", name: p.name, createdAt: nowIso(), lastSeenAt: nowIso() };
  db.users = [row];
  db.currentUserId = 1;
  const d = (p.data ?? {}) as Partial<DB>;
  db.seq = Math.max(Number(d.seq) || 0, 1);
  const fix = <T extends { userId: number }>(a: T[] | undefined) => (a ?? []).map((x) => ({ ...x, userId: 1 }));
  db.assessments = fix(d.assessments);
  db.workoutPlans = fix(d.workoutPlans);
  db.workoutLogs = fix(d.workoutLogs);
  db.dayCompletions = fix(d.dayCompletions);
  db.weightLogs = fix(d.weightLogs);
  db.achievements = fix(d.achievements);
  saveDb();
  startSync();
}

async function loadMe(): Promise<UserRow | null> {
  const p = await cloudProfile();
  if (!p) return null;
  hydrate(p);
  return getDb().users[0];
}

const num = (v: unknown, fallback = 0) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
};

/* ───────────── مسیرها ───────────── */

const routes: Record<string, Handler> = {
  /* --- حساب کاربری --- */
  "GET /auth/me": async () => {
    const db = getDb();
    let row = db.currentUserId != null ? db.users[0] : null;
    try {
      const { data: sess } = await sb.auth.getSession();
      if (!sess.session) {
        cloudMe = null;
        stopSync();
        return { user: null };
      }
      const p = await cloudProfile();
      if (p) {
        const same = row && cloudMe && cloudMe.id === p.id;
        if (same) cloudMe = p;
        else hydrate(p);
        row = getDb().users[0];
      }
    } catch {
      // آفلاین: اگر قبلاً وارد شده بود، با اطلاعات ذخیره‌شده ادامه بده
      if (!row || !cloudMe) return { user: null };
    }
    if (!row) return { user: null };
    return { user: toMe(getDb(), row) };
  },

  "POST /auth/register": async (body) => {
    const phone = normalizePhone(String(body?.phone ?? ""));
    const password = String(body?.password ?? "");
    const name = String(body?.name ?? "").trim().slice(0, 40) || null;
    if (!isValidPhone(phone)) return fail("شماره موبایل معتبر نیست");
    if (password.length < 6) return fail("رمز عبور حداقل ۶ کاراکتر باشد");
    const { data, error } = await sb.auth.signUp({ email: phoneToEmail(phone), password });
    if (error) return fail(cloudErr(error));
    if (!data.session) return fail("ثبت‌نام انجام شد ولی ورود خودکار نشد؛ از صفحه ورود وارد شو.");
    if (name) await sb.from("profiles").update({ name }).eq("id", data.session.user.id);
    const row = await loadMe();
    if (!row) return fail("پروفایل ساخته نشد؛ دوباره تلاش کن.");
    return { user: { id: row.id, phone: row.phone, name: row.name } };
  },

  "POST /auth/login": async (body) => {
    const phone = normalizePhone(String(body?.phone ?? ""));
    const password = String(body?.password ?? "");
    if (!isValidPhone(phone)) return fail("شماره موبایل معتبر نیست");
    const { error } = await sb.auth.signInWithPassword({ email: phoneToEmail(phone), password });
    if (error) return fail(cloudErr(error), 401);
    const row = await loadMe();
    if (!row) return fail("پروفایل پیدا نشد", 401);
    return { user: { id: row.id, phone: row.phone, name: row.name } };
  },

  "POST /auth/logout": async () => {
    try {
      await pushNow();
    } catch {
      /* ignore */
    }
    stopSync();
    await sb.auth.signOut().catch(() => {});
    cloudMe = null;
    resetDb();
    return {};
  },

  /* --- تنظیمات --- */
  "GET /config": async () => ({
    monthlyPrice: await sb.rpc("get_price").then((r) => (typeof r.data === "number" ? r.data : APP_CONFIG.monthlyPrice), () => APP_CONFIG.monthlyPrice),
    paymentMode: APP_CONFIG.paymentMode,
    sku: APP_CONFIG.sku,
    packageName: APP_CONFIG.packageName,
    hasRsa: Boolean(APP_CONFIG.rsaPublicKey),
    appName: APP_CONFIG.appName,
  }),

  /* --- دانشنامه حرکات --- */
  "GET /exercises": () => {
    const logged = Boolean(currentUser(getDb()));
    return {
      exercises: EXERCISES.map((e) => ({
        id: e.id,
        nameFa: e.nameFa,
        nameEn: e.nameEn,
        muscle: e.muscle,
        level: e.level,
        image: e.image,
        equipment: e.equipment,
        instructions: logged ? e.instructions : e.instructions.slice(0, 1),
        tip: logged ? e.tip : "برای دیدن نکات مربی وارد شو",
      })),
    };
  },

  /* --- ارزیابی و برنامه --- */
  "GET /assessment": () => {
    const db = getDb();
    const { row } = requireUser(db);
    const list = db.assessments.filter((a) => a.userId === row.id).sort((a, b) => b.id - a.id);
    return { assessment: list[0] ?? null };
  },

  "POST /assessment": (body) => {
    const db = getDb();
    const { row, me } = requireUser(db);
    if (!me.isPremium) return fail("برای دریافت برنامه اختصاصی باید اشتراک فعال داشته باشی", 403);
    if (!body) return fail("پاسخ‌ها ناقص است");

    const answers = { ...(body as unknown as AssessmentAnswers) };
    const height = num(answers.height);
    const weight = num(answers.weight);
    if (!height || !weight || height < 120 || height > 230 || weight < 35 || weight > 220) {
      return fail("قد یا وزن معتبر نیست");
    }
    answers.height = height;
    answers.weight = weight;

    const required = [
      "gender", "age", "goal", "experience", "days", "duration", "focus",
      "equipment", "injury", "style", "intensity", "activity", "sleep", "cardio", "weak",
    ] as const;
    for (const key of required) {
      if (!answers[key]) return fail("همه سوال‌ها را جواب بده");
    }
    if (!Array.isArray(answers.priority) || answers.priority.length === 0) {
      answers.priority = ["chest", "back"];
    }

    const plan = generatePlan(answers);
    db.assessments.push({
      id: nextId(db),
      userId: row.id,
      answers,
      height,
      weight,
      bmi: bmiOf(height, weight),
      createdAt: nowIso(),
    });
    const planId = nextId(db);
    db.workoutPlans.push({
      id: planId,
      userId: row.id,
      title: plan.title,
      summary: plan.subtitle,
      durationWeeks: plan.weeks,
      daysPerWeek: plan.daysPerWeek,
      plan,
      createdAt: nowIso(),
    });
    saveDb();
    return { planId, plan };
  },

  "GET /plan": () => {
    const db = getDb();
    const { row } = requireUser(db);
    const current = db.workoutPlans.filter((p) => p.userId === row.id).sort((a, b) => b.id - a.id)[0];
    if (!current) {
      return { plan: null, freeSession: FREE_SESSION, completions: [], logs: [] };
    }
    return {
      planId: current.id,
      plan: current.plan,
      createdAt: current.createdAt,
      completions: db.dayCompletions.filter((c) => c.planId === current.id && c.userId === row.id),
      logs: db.workoutLogs.filter((l) => l.planId === current.id && l.userId === row.id),
      freeSession: FREE_SESSION,
    };
  },

  /* --- پروفایل --- */
  "GET /profile": () => {
    const db = getDb();
    const { row, me } = requireUser(db);
    return {
      user: me,
      payments: db.payments.filter((p) => p.userId === row.id).sort((a, b) => b.id - a.id),
      subscriptions: db.subscriptions.filter((s) => s.userId === row.id).sort((a, b) => b.id - a.id),
    };
  },

  "POST /profile": (body) => {
    const db = getDb();
    const { row } = requireUser(db);
    const name = String(body?.name ?? "").trim().slice(0, 40);
    if (!name) return fail("نام را وارد کن");
    row.name = name;
    saveDb();
    return { name };
  },

  /* --- پیشرفت --- */
  "GET /progress": () => {
    const db = getDb();
    const { row } = requireUser(db);
    const weights = db.weightLogs.filter((w) => w.userId === row.id).sort((a, b) => b.id - a.id);
    const days = db.dayCompletions.filter((d) => d.userId === row.id).sort((a, b) => b.id - a.id);
    const logs = db.workoutLogs.filter((l) => l.userId === row.id);
    const badges = db.achievements.filter((a) => a.userId === row.id);
    const xp = days.reduce((s, d) => s + (d.xp ?? 0), 0);
    const calories = days.reduce((s, d) => s + (d.calories ?? 0), 0);
    return {
      weights,
      days,
      badges,
      stats: {
        xp,
        calories,
        workouts: days.length,
        exercises: logs.filter((l) => l.status === "completed").length,
        level: Math.max(1, Math.floor(xp / 250) + 1),
      },
    };
  },

  "POST /progress": (body) => {
    const db = getDb();
    const { row } = requireUser(db);
    const weight = num(String(body?.weight ?? "").replace(",", "."));
    if (!weight || weight < 30 || weight > 250) return fail("وزن معتبر نیست");
    db.weightLogs.push({
      id: nextId(db),
      userId: row.id,
      weight,
      note: body?.note ? String(body.note) : null,
      createdAt: nowIso(),
    });
    saveDb();
    return { saved: true };
  },

  /* --- ثبت تمرین --- */
  "POST /workout/log": (body) => {
    const db = getDb();
    const { row } = requireUser(db);
    if (!body || body.dayIndex === undefined || !body.exerciseId || !body.status) {
      return fail("داده ناقص");
    }
    const planId = num(body.planId);
    if (planId && !db.workoutPlans.some((p) => p.id === planId && p.userId === row.id)) {
      return fail("برنامه پیدا نشد", 404);
    }
    db.workoutLogs.push({
      id: nextId(db),
      userId: row.id,
      planId,
      dayIndex: num(body.dayIndex),
      exerciseId: String(body.exerciseId),
      status: String(body.status),
      setsDone: num(body.setsDone),
      durationSec: num(body.durationSec),
      createdAt: nowIso(),
    });
    saveDb();
    return { saved: true };
  },

  "PUT /workout/log": (body) => {
    const db = getDb();
    const { row } = requireUser(db);
    if (!body || body.dayIndex === undefined) return fail("داده ناقص");

    db.dayCompletions.push({
      id: nextId(db),
      userId: row.id,
      planId: num(body.planId),
      dayIndex: num(body.dayIndex),
      calories: num(body.calories),
      durationSec: num(body.durationSec),
      xp: body.xp === undefined ? 80 : num(body.xp, 80),
      completedAt: nowIso(),
    });

    // اصلاح باگ قدیمی: تعداد جلسه‌ها بعد از ثبت حساب می‌شود (قبلاً یکی اضافه شمرده می‌شد)
    const total = db.dayCompletions.filter((d) => d.userId === row.id).length;
    const have = new Set(db.achievements.filter((a) => a.userId === row.id).map((a) => a.code));
    const unlocks: { code: string; title: string }[] = [];
    if (!have.has("first_workout")) unlocks.push({ code: "first_workout", title: "اولین جلسه فورج شد" });
    if (total >= 7 && !have.has("week_warrior")) unlocks.push({ code: "week_warrior", title: "۷ جلسه کامل" });
    if (total >= 20 && !have.has("iron_will")) unlocks.push({ code: "iron_will", title: "اراده آهنی" });
    for (const u of unlocks) {
      db.achievements.push({ id: nextId(db), userId: row.id, code: u.code, title: u.title, unlockedAt: nowIso() });
    }
    saveDb();
    return { completed: true, unlocks };
  },

  /* --- پرداخت مایکت (ثبت روی سرور) --- */
  "POST /payment/myket/init": async () => {
    const { me } = requireUser(getDb());
    if (me.isPremium) return fail("اشتراک فعال داری");
    const { data, error } = await sb.rpc("begin_payment", { p_sku: APP_CONFIG.sku });
    if (error) return fail(cloudErr(error));
    const r = data as { payment_id: number; amount: number; payload: string };
    return {
      paymentId: r.payment_id,
      amount: r.amount,
      sku: APP_CONFIG.sku,
      payload: r.payload,
      packageName: APP_CONFIG.packageName,
      rsaPublicKey: APP_CONFIG.rsaPublicKey,
      paymentMode: APP_CONFIG.paymentMode,
    };
  },

  "POST /payment/myket/verify": async (body) => {
    requireUser(getDb());
    const paymentId = num(body?.paymentId);
    if (!paymentId) return fail("شناسه پرداخت نیست");
    const purchase = (body?.purchase ?? {}) as MyketPurchase;
    // فقط رسیدی که امضای RSA مایکت‌اش تأیید شده به سرور فرستاده می‌شود؛ سرور هم دوباره SKU و payload و تکراری‌نبودن را چک می‌کند
    if (!purchase.signatureVerified || !purchase.purchaseToken) {
      await sb.rpc("fail_payment", { p_payment_id: paymentId, p_status: "failed", p_error: "signature" });
      return fail("پرداخت تأیید نشد؛ اشتراک فعال نمی‌شود");
    }
    const { data, error } = await sb.rpc("complete_payment", { p_payment_id: paymentId, p_purchase: purchase });
    if (error) {
      await sb.rpc("fail_payment", { p_payment_id: paymentId, p_status: "failed", p_error: String(error.message).slice(0, 100) });
      return fail(cloudErr(error));
    }
    const p = await cloudProfile();
    if (p) cloudMe = p;
    return { activated: true, expiresAt: (data as { premium_until?: string })?.premium_until ?? null };
  },

  "POST /payment/myket/fail": async (body) => {
    const paymentId = num(body?.paymentId);
    if (paymentId) {
      await sb.rpc("fail_payment", { p_payment_id: paymentId, p_status: body?.canceled ? "canceled" : "failed", p_error: String(body?.error ?? "").slice(0, 100) });
    }
    return {};
  },

  /* --- پنل ادمین (همه‌ی چک‌ها سمت سرور) --- */
  "GET /admin/overview": async () => {
    const [st, us, pay] = await Promise.all([sb.rpc("admin_stats"), sb.rpc("admin_users", { p_q: "", p_limit: 30 }), sb.rpc("admin_payments", { p_limit: 30 })]);
    const err = st.error || us.error || pay.error;
    if (err) return fail(cloudErr(err), 403);
    return { stats: st.data, users: us.data, payments: pay.data };
  },
  "POST /admin/users": async (body) => {
    const { data, error } = await sb.rpc("admin_users", { p_q: String(body?.q ?? ""), p_limit: 50 });
    if (error) return fail(cloudErr(error));
    return { users: data };
  },
  "POST /admin/grant": async (body) => {
    const phone = normalizePhone(String(body?.phone ?? ""));
    const { data, error } = await sb.rpc("admin_grant", { p_phone: phone, p_days: num(body?.days) });
    if (error) return fail(cloudErr(error));
    return { premiumUntil: (data as { premium_until?: string })?.premium_until ?? null };
  },
  "POST /admin/revoke": async (body) => {
    const { error } = await sb.rpc("admin_revoke", { p_phone: normalizePhone(String(body?.phone ?? "")) });
    if (error) return fail(cloudErr(error));
    return {};
  },
  "POST /admin/price": async (body) => {
    const { error } = await sb.rpc("admin_set_price", { p_amount: num(body?.amount) });
    if (error) return fail(cloudErr(error));
    return {};
  },
};

/* ───────────── نقطه ورود ───────────── */

function reply(data: Json, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

type FetchInit = { method?: string; headers?: unknown; body?: string | null };

export async function apiFetch(input: string, init: FetchInit = {}): Promise<Response> {
  const method = (init.method || "GET").toUpperCase();
  const path = input.split("?")[0].replace(/^\/api/, "");
  let body: Body = null;
  if (init.body) {
    try {
      body = JSON.parse(init.body) as Body;
    } catch {
      body = null;
    }
  }
  try {
    const handler = routes[`${method} ${path}`];
    if (!handler) return reply({ ok: false, error: "مسیر پیدا نشد" }, 404);
    const data = await handler(body);
    return reply({ ok: true, ...data });
  } catch (e) {
    if (e instanceof HttpError) return reply({ ok: false, error: e.message }, e.status);
    console.error("[forja] api error", e);
    return reply({ ok: false, error: "خطای غیرمنتظره. دوباره تلاش کن." }, 500);
  }
}
