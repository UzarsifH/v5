/**
 * پرداخت درون‌برنامه‌ای مایکت (IAB) از طریق پلاگین بومی MyketBilling
 * (کد جاوا: native/android — با scripts/patch-android.mjs داخل پروژه اندروید گذاشته می‌شود)
 * رسید با امضای RSA کلید عمومی پنل مایکت داخل خود اپ تأیید می‌شود.
 */
import { Capacitor, registerPlugin } from "@capacitor/core";

export type MyketPurchase = {
  orderId?: string;
  packageName?: string;
  productId?: string;
  purchaseTime?: number;
  purchaseState?: number;
  developerPayload?: string;
  purchaseToken?: string;
  sku?: string;
  signatureVerified?: boolean;
};

type Raw = { purchaseData: string; signature: string };

const Native = registerPlugin<{
  purchase(o: { sku: string; payload: string }): Promise<Raw>;
  owned(): Promise<{ items: Raw[] }>;
  consume(o: { purchaseToken: string }): Promise<{ code: number }>;
}>("MyketBilling");

export const isNativeAndroid = () => Capacitor.getPlatform() === "android";

const b64 = (s: string) => Uint8Array.from(atob(s.replace(/\s/g, "")), (c) => c.charCodeAt(0));

export async function verifySignature(rsaKey: string, data: string, signature: string) {
  try {
    const key = await crypto.subtle.importKey("spki", b64(rsaKey), { name: "RSASSA-PKCS1-v1_5", hash: "SHA-1" }, false, ["verify"]);
    return await crypto.subtle.verify("RSASSA-PKCS1-v1_5", key, b64(signature), new TextEncoder().encode(data));
  } catch {
    return false;
  }
}

async function toPurchase(raw: Raw, rsaKey: string): Promise<MyketPurchase> {
  const p = JSON.parse(raw.purchaseData) as MyketPurchase;
  p.signatureVerified = (await verifySignature(rsaKey, raw.purchaseData, raw.signature)) && (p.purchaseState ?? 0) === 0;
  return p;
}

/** شروع خرید؛ اگر قبلاً خریده شده ولی مصرف نشده بود همان را برمی‌گرداند */
export async function buy(sku: string, payload: string, rsaKey: string): Promise<MyketPurchase> {
  try {
    return await toPurchase(await Native.purchase({ sku, payload }), rsaKey);
  } catch (e) {
    if ((e as { code?: string })?.code === "7") {
      const { items } = await Native.owned();
      for (const it of items) {
        const p = await toPurchase(it, rsaKey);
        if (p.productId === sku) return { ...p, developerPayload: payload };
      }
    }
    throw e;
  }
}

export const consume = (purchaseToken: string) => Native.consume({ purchaseToken }).catch(() => null);
