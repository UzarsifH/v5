import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { Capacitor } from "@capacitor/core";
import { SplashScreen } from "@capacitor/splash-screen";
import { StatusBar, Style } from "@capacitor/status-bar";
import "@fontsource/vazirmatn/400.css";
import "@fontsource/vazirmatn/500.css";
import "@fontsource/vazirmatn/600.css";
import "@fontsource/vazirmatn/700.css";
import "@fontsource/vazirmatn/800.css";
import "./index.css";
import App from "./App";
import { trackInstall } from "@/lib/cloud";

/* اگر عکسی لود نشد (مثلاً آفلاین بودن)، به‌جای آیکون شکسته یک پس‌زمینه‌ی تیره می‌گذاریم */
const FALLBACK_IMG =
  "data:image/svg+xml;utf8," +
  encodeURIComponent(
    "<svg xmlns='http://www.w3.org/2000/svg' width='800' height='1200' viewBox='0 0 800 1200'>" +
      "<defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'>" +
      "<stop offset='0' stop-color='#1a2108'/><stop offset='1' stop-color='#2b1309'/></linearGradient></defs>" +
      "<rect width='800' height='1200' fill='url(#g)'/></svg>",
  );

document.addEventListener(
  "error",
  (e) => {
    const t = e.target;
    if (t instanceof HTMLImageElement && !t.dataset.fallback) {
      t.dataset.fallback = "1";
      t.src = FALLBACK_IMG;
    }
  },
  true,
);

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);

trackInstall();

if (Capacitor.isNativePlatform()) {
  void StatusBar.setStyle({ style: Style.Dark }).catch(() => {});
  void StatusBar.setBackgroundColor({ color: "#07070a" }).catch(() => {});
  setTimeout(() => void SplashScreen.hide().catch(() => {}), 150);
}
