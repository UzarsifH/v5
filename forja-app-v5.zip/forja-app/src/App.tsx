import { HashRouter, Route, Routes } from "react-router-dom";
import { Providers } from "@/components/Providers";
import AssessPage from "@/pages/Assess";
import AdminPage from "@/pages/Admin";
import ExplorePage from "@/pages/Explore";
import HomePage from "@/pages/Home";
import LoginPage from "@/pages/Login";
import NotFound from "@/pages/NotFound";
import PayPage from "@/pages/Pay";
import PlanPage from "@/pages/Plan";
import PrintPlanPage from "@/pages/PlanPrint";
import ProfilePage from "@/pages/Profile";
import ProgressPage from "@/pages/Progress";
import RegisterPage from "@/pages/Register";
import SplashPage from "@/pages/Splash";
import SubscribePage from "@/pages/Subscribe";
import TrainPage from "@/pages/Train";
import WorkoutPlayerPage from "@/pages/Workout";

export default function App() {
  return (
    <HashRouter>
      <Providers>
        <Routes>
          <Route path="/" element={<SplashPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/home" element={<HomePage />} />
          <Route path="/admin" element={<AdminPage />} />
          <Route path="/explore" element={<ExplorePage />} />
          <Route path="/train" element={<TrainPage />} />
          <Route path="/progress" element={<ProgressPage />} />
          <Route path="/profile" element={<ProfilePage />} />
          <Route path="/subscribe" element={<SubscribePage />} />
          <Route path="/pay" element={<PayPage />} />
          <Route path="/assess" element={<AssessPage />} />
          <Route path="/plan" element={<PlanPage />} />
          <Route path="/plan/print" element={<PrintPlanPage />} />
          <Route path="/workout/:day" element={<WorkoutPlayerPage />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Providers>
    </HashRouter>
  );
}
