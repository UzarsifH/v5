import { apiFetch } from "@/lib/api";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { Capacitor } from "@capacitor/core";
import { App as CapApp } from "@capacitor/app";
import { usePathname, useRouter } from "@/lib/nav";
import type { MeUser } from "@/lib/types";

type AuthState = {
  user: MeUser | null;
  loading: boolean;
  refresh: () => Promise<void>;
  logout: () => Promise<void>;
};

const AuthCtx = createContext<AuthState>({
  user: null,
  loading: true,
  refresh: async () => {},
  logout: async () => {},
});

export function useAuth() {
  return useContext(AuthCtx);
}

function Icon({ d }: { d: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d={d} />
    </svg>
  );
}

function BottomNav() {
  const path = usePathname();
  const router = useRouter();
  const items = [
    { href: "/home", label: "خانه", d: "M3 11.5 12 4l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z" },
    { href: "/explore", label: "حرکات", d: "M4 6h16M4 12h10M4 18h16" },
    { href: "/train", label: "تمرین", d: "M6 7h12v10H6zM9 3v4M15 3v4M9 17v4M15 17v4" },
    { href: "/progress", label: "پیشرفت", d: "M4 19V9l5 4 4-8 7 10" },
    { href: "/profile", label: "پروفایل", d: "M12 12a4 4 0 1 0-4-4 4 4 0 0 0 4 4zm-7 8a7 7 0 0 1 14 0" },
  ];
  return (
    <nav className="nav-bar">
      {items.map((it) => (
        <button
          key={it.href}
          className={`nav-item ${path.startsWith(it.href) ? "active" : ""}`}
          onClick={() => router.push(it.href)}
        >
          <Icon d={it.d} />
          {it.label}
        </button>
      ))}
    </nav>
  );
}

const TAB_PATHS = ["/explore", "/train", "/progress", "/profile"];
const EXIT_PATHS = ["/", "/home", "/login"];

export function Providers({ children }: { children: ReactNode }) {
  const path = usePathname();
  const router = useRouter();
  const scrollRef = useRef<HTMLDivElement>(null);
  const pathRef = useRef(path);
  pathRef.current = path;
  const [user, setUser] = useState<MeUser | null>(null);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    try {
      const res = await apiFetch("/api/auth/me");
      const data = (await res.json()) as { user: MeUser | null };
      setUser(data.user ?? null);
    } catch {
      setUser(null);
    } finally {
      // قبلاً اگر این درخواست خطا می‌داد، loading برای همیشه true می‌ماند و اپ روی اسکلت لودینگ گیر می‌کرد
      setLoading(false);
    }
  }, []);

  const logout = useCallback(async () => {
    try {
      await apiFetch("/api/auth/logout", { method: "POST" });
    } finally {
      setUser(null);
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  // بالا رفتن صفحه با هر تغییر مسیر
  useEffect(() => {
    scrollRef.current?.scrollTo({ top: 0 });
  }, [path]);

  // دکمه‌ی بازگشت اندروید
  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return;
    const handle = CapApp.addListener("backButton", () => {
      const p = pathRef.current;
      if (EXIT_PATHS.includes(p)) void CapApp.exitApp();
      else if (TAB_PATHS.includes(p)) router.replace("/home");
      else router.back();
    });
    return () => {
      void handle.then((h) => h.remove());
    };
  }, [router]);

  const value = useMemo(() => ({ user, loading, refresh, logout }), [user, loading, refresh, logout]);
  const isPrint = path.startsWith("/plan/print");
  const hideNav = ["/", "/login", "/register", "/subscribe", "/pay", "/assess", "/admin"].includes(path) || path.startsWith("/workout");

  if (isPrint) {
    return <AuthCtx.Provider value={value}>{children}</AuthCtx.Provider>;
  }

  return (
    <AuthCtx.Provider value={value}>
      <div className="app-stage">
        <div className="phone">
          <div className="orb orb-a" />
          <div className="orb orb-b" />
          <div ref={scrollRef} className={hideNav ? "phone-scroll no-nav" : "phone-scroll"}>
            {children}
          </div>
          {!hideNav && <BottomNav />}
        </div>
      </div>
    </AuthCtx.Provider>
  );
}

export function RippleButton({
  className,
  children,
  onClick,
  disabled,
  type = "button",
}: {
  className?: string;
  children: ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  type?: "button" | "submit";
}) {
  const [ripples, setRipples] = useState<{ x: number; y: number; id: number }[]>([]);
  return (
    <button
      type={type}
      disabled={disabled}
      className={`btn ${className ?? ""}`}
      onClick={(e) => {
        const rect = e.currentTarget.getBoundingClientRect();
        const id = Date.now();
        setRipples((r) => [...r, { x: e.clientX - rect.left, y: e.clientY - rect.top, id }]);
        setTimeout(() => setRipples((r) => r.filter((x) => x.id !== id)), 600);
        onClick?.();
      }}
    >
      {ripples.map((r) => (
        <span key={r.id} className="ripple" style={{ left: r.x, top: r.y, width: 16, height: 16 }} />
      ))}
      {children}
    </button>
  );
}
