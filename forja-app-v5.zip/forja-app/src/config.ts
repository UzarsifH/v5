/**
 * تنظیمات عمومی اپ. اطلاعات حساس مثل رمز دیتابیس/توکن سرور هرگز داخل APK قرار نمی‌گیرد.
 */
export const APP_CONFIG = {
  appName: "فُرجا",
  packageName: "ir.forja.app",
  monthlyPrice: 249000,
  sku: "M2",
  paymentMode: "live" as "sandbox" | "live",
  rsaPublicKey:
    "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCSeZHIro/8xE0fsPWyZGrtLO1105xcTM+nn75T/ASbRi8kBhj3bixdG8FVs262EcAjl+B0XzokhzMABUSu2HyENj/8anTFfI6A3eGfYmifGYKafhDkb4dRvBWgZtam69Q5dGweV09C0U2DPLsEYqPlz75scsjo6I4hDQZdr0fE/wIDAQAB",
  myketAppId: "app_v1_2e4fb3a5-968a-4ca4-9148-ca4fbe8b73e2",
  subscriptionDays: 30,
};
