/**
 * تنظیمات اصلی اپ فُرجا
 * (قبلاً این مقادیر در دیتابیس / پنل ادمین بود؛ حالا اینجا ثابت‌اند.)
 */
export const APP_CONFIG = {
  appName: "فُرجا",
  /** باید با appId داخل capacitor.config.json و پنل مایکت یکی باشد */
  packageName: "ir.forja.app",
  /** قیمت اشتراک ماهانه (تومان) */
  monthlyPrice: 249000,
  /** شناسه‌ی محصول (SKU) اشتراک ماهانه در پنل مایکت */
  sku: "M2",
  /**
   * "sandbox" = خرید آزمایشی؛ اشتراک بدون پرداخت واقعی فعال می‌شود (برای تست).
   * "live"    = فقط وقتی پرداخت واقعی مایکت (MyketBridge) داخل اپ وصل باشد.
   *             راهنما: README.md بخش «پرداخت مایکت»
   */
  paymentMode: "live" as "sandbox" | "live",
  /** کلید RSA عمومی پنل مایکت (برای حالت live) */
  rsaPublicKey:
    "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCSeZHIro/8xE0fsPWyZGrtLO1105xcTM+nn75T/ASbRi8kBhj3bixdG8FVs262EcAjl+B0XzokhzMABUSu2HyENj/8anTFfI6A3eGfYmifGYKafhDkb4dRvBWgZtam69Q5dGweV09C0U2DPLsEYqPlz75scsjo6I4hDQZdr0fE/wIDAQAB",
  /** شناسه‌ی برنامه در پنل مایکت (فقط برای مرجع) */
  myketAppId: "ed094228-0fdd-4274-8d8e-d1d84c5011c5",
  /** Supabase (کلید publishable عمومی است و طبق طراحی داخل اپ قرار می‌گیرد) */
  supabaseUrl: "https://fmpkueeghxzleknsqlkt.supabase.co",
  supabaseKey: "sb_publishable_zq2wk9CLunDukELjHwTLQw_mObMnE7v",
  /** مدت اعتبار هر اشتراک (روز) */
  subscriptionDays: 30,
};
