-- ساخت حساب ادمین (یک‌بار اجرا کن). قبل از Run، عبارت __ADMIN_PASSWORD__ را با رمز دلخواه عوض کن.
-- نکته: رمز واقعی را داخل این فایل (مخصوصاً اگر repo عمومی است) ذخیره نکن.
create extension if not exists pgcrypto;
do $$
declare v_id uuid;
begin
  if not exists (select 1 from auth.users where email = '09392871492@forja.app') then
    v_id := gen_random_uuid();
    insert into auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at,
      raw_app_meta_data, raw_user_meta_data, created_at, updated_at, confirmation_token, email_change, email_change_token_new, recovery_token)
    values ('00000000-0000-0000-0000-000000000000', v_id, 'authenticated', 'authenticated', '09392871492@forja.app',
      crypt('__ADMIN_PASSWORD__', gen_salt('bf')), now(), '{"provider":"email","providers":["email"]}', '{}', now(), now(), '', '', '', '');
    insert into auth.identities (id, user_id, provider_id, identity_data, provider, last_sign_in_at, created_at, updated_at)
    values (gen_random_uuid(), v_id, v_id::text, jsonb_build_object('sub', v_id::text, 'email', '09392871492@forja.app', 'email_verified', true), 'email', now(), now(), now());
  end if;
end $$;

-- (اگر پروفایل ساخته شده، ادمینش کن)
update public.profiles set is_admin = true, name = coalesce(name, 'ادمین') where phone = '09392871492';
select phone, is_admin from public.profiles where phone = '09392871492';
