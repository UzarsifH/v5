-- FORJA FINAL RPC REPAIR
-- Run this file in Supabase SQL Editor after the main schema.sql has been applied.
-- It removes stale overloads, then asks PostgREST to reload its schema cache.

begin;
drop function if exists public.forja_api(jsonb,text,text,text,text);
drop function if exists public.forja_api(text,text,jsonb,text,text);
commit;

-- IMPORTANT: Now run supabase/schema.sql from the project immediately after this file.
-- The corrected schema.sql creates the function with:
-- forja_api(jsonb,text,text,text,text)
-- and grants execute using that exact signature.

notify pgrst, 'reload schema';
