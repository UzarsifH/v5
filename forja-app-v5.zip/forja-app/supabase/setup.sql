-- ============================================================
--  فُرجا | راه‌اندازی دیتابیس Supabase
--  Supabase → SQL Editor → New query → همه‌ی این متن را Paste کن → Run
--  (چند بار اجرا کردنش مشکلی ایجاد نمی‌کند)
-- ============================================================
create extension if not exists pgcrypto;

-- ---------- جدول‌ها ----------
create table if not exists public.profiles (
  id            uuid primary key references auth.users(id) on delete cascade,
  phone         text unique not null,
  name          text,
  is_admin      boolean not null default false,
  premium_until timestamptz,
  data          jsonb not null default '{}'::jsonb,   -- برنامه، تمرین‌ها، وزن‌ها و ... (برای بازیابی بعد از حذف اپ)
  created_at    timestamptz not null default now(),
  last_seen     timestamptz not null default now()
);

create table if not exists public.payments (
  id             bigserial primary key,
  user_id        uuid references auth.users(id) on delete set null,
  phone          text,
  sku            text not null,
  amount         integer not null,
  status         text not null default 'pending' check (status in ('pending','success','failed','canceled')),
  source         text not null default 'myket',
  payload        text,
  order_id       text,
  purchase_token text unique,
  error          text,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
create index if not exists payments_status_idx on public.payments(status);
create index if not exists payments_user_idx   on public.payments(user_id);

create table if not exists public.installs (
  device_id  text primary key,
  platform   text,
  first_seen timestamptz not null default now(),
  last_seen  timestamptz not null default now()
);

create table if not exists public.app_settings (
  key   text primary key,
  value jsonb not null
);
insert into public.app_settings(key, value) values ('monthly_price', '249000'::jsonb) on conflict (key) do nothing;

-- ---------- ساخت خودکار پروفایل بعد از ثبت‌نام ----------
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id, phone) values (new.id, split_part(new.email, '@', 1))
  on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------- امنیت (RLS) ----------
alter table public.profiles     enable row level security;
alter table public.payments     enable row level security;
alter table public.installs     enable row level security;
alter table public.app_settings enable row level security;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select is_admin from public.profiles where id = auth.uid()), false)
$$;

revoke all on public.profiles, public.payments, public.installs, public.app_settings from anon, authenticated;

-- هر کاربر فقط پروفایل خودش را می‌بیند و فقط name/data/last_seen را می‌تواند تغییر دهد (نه اشتراک، نه ادمین‌بودن)
grant select on public.profiles to authenticated;
grant update (name, data, last_seen) on public.profiles to authenticated;
drop policy if exists "profile_select_own" on public.profiles;
create policy "profile_select_own" on public.profiles for select to authenticated using (id = auth.uid());
drop policy if exists "profile_update_own" on public.profiles;
create policy "profile_update_own" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

grant select on public.payments to authenticated;
drop policy if exists "payments_select_own" on public.payments;
create policy "payments_select_own" on public.payments for select to authenticated using (user_id = auth.uid());

grant select on public.app_settings to anon, authenticated;
drop policy if exists "settings_read" on public.app_settings;
create policy "settings_read" on public.app_settings for select to anon, authenticated using (true);

-- ---------- توابع عمومی ----------
create or replace function public.get_price() returns integer
language sql stable security definer set search_path = public as $$
  select (value #>> '{}')::int from public.app_settings where key = 'monthly_price'
$$;

create or replace function public.track_install(p_device text, p_platform text default 'android') returns void
language plpgsql security definer set search_path = public as $$
begin
  if p_device is null or length(p_device) < 8 or length(p_device) > 64 then return; end if;
  insert into public.installs(device_id, platform) values (p_device, left(coalesce(p_platform, ''), 20))
  on conflict (device_id) do update set last_seen = now();
end $$;

-- ---------- پرداخت ----------
create or replace function public.begin_payment(p_sku text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); v_phone text; v_amount int; v_id bigint; v_payload text;
begin
  if v_uid is null then raise exception 'not_authenticated'; end if;
  select phone into v_phone from public.profiles where id = v_uid;
  v_amount  := public.get_price();
  v_payload := 'forja:' || v_uid::text || ':' || encode(gen_random_bytes(6), 'hex');
  select id into v_id from public.payments where user_id = v_uid and status = 'pending' order by id desc limit 1;
  if v_id is null then
    insert into public.payments(user_id, phone, sku, amount, payload) values (v_uid, v_phone, p_sku, v_amount, v_payload) returning id into v_id;
  else
    update public.payments set sku = p_sku, amount = v_amount, payload = v_payload, updated_at = now() where id = v_id;
  end if;
  return jsonb_build_object('payment_id', v_id, 'amount', v_amount, 'payload', v_payload);
end $$;

create or replace function public.complete_payment(p_payment_id bigint, p_purchase jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); r public.payments%rowtype; v_token text; v_until timestamptz;
begin
  if v_uid is null then raise exception 'not_authenticated'; end if;
  select * into r from public.payments where id = p_payment_id and user_id = v_uid for update;
  if not found then raise exception 'payment_not_found'; end if;
  if r.status = 'success' then
    select premium_until into v_until from public.profiles where id = v_uid;
    return jsonb_build_object('premium_until', v_until, 'already', true);
  end if;
  v_token := p_purchase ->> 'purchaseToken';
  if v_token is null or length(v_token) < 5 then raise exception 'bad_token'; end if;
  if coalesce(p_purchase ->> 'productId', '') <> r.sku then raise exception 'sku_mismatch'; end if;
  if (p_purchase ? 'packageName') and (p_purchase ->> 'packageName') <> 'ir.forja.app' then raise exception 'package_mismatch'; end if;
  if (p_purchase ? 'developerPayload') and coalesce(p_purchase ->> 'developerPayload', '') <> '' and (p_purchase ->> 'developerPayload') <> r.payload then raise exception 'payload_mismatch'; end if;
  if coalesce(p_purchase ->> 'purchaseState', '0') <> '0' then raise exception 'not_purchased'; end if;
  if exists (select 1 from public.payments where purchase_token = v_token) then raise exception 'token_used'; end if;
  update public.payments set status = 'success', purchase_token = v_token, order_id = p_purchase ->> 'orderId', error = null, updated_at = now() where id = r.id;
  update public.profiles set premium_until = greatest(now(), coalesce(premium_until, now())) + make_interval(days => 30)
   where id = v_uid returning premium_until into v_until;
  return jsonb_build_object('premium_until', v_until);
end $$;

create or replace function public.fail_payment(p_payment_id bigint, p_status text default 'failed', p_error text default null) returns void
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then return; end if;
  update public.payments
     set status = case when p_status = 'canceled' then 'canceled' else 'failed' end, error = left(coalesce(p_error, ''), 200), updated_at = now()
   where id = p_payment_id and user_id = auth.uid() and status = 'pending';
end $$;

-- ---------- پنل ادمین (همه چک ادمین‌بودن سمت سرور دارند) ----------
create or replace function public.admin_stats() returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'forbidden'; end if;
  return jsonb_build_object(
    'installs',    (select count(*) from public.installs),
    'users',       (select count(*) from public.profiles),
    'active_subs', (select count(*) from public.profiles where premium_until > now()),
    'success',     (select count(*) from public.payments where status = 'success' and source = 'myket'),
    'failed',      (select count(*) from public.payments where status in ('failed', 'canceled')),
    'pending',     (select count(*) from public.payments where status = 'pending'),
    'revenue',     (select coalesce(sum(amount), 0) from public.payments where status = 'success' and source = 'myket'),
    'price',       public.get_price());
end $$;

create or replace function public.admin_users(p_q text default '', p_limit int default 50) returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'forbidden'; end if;
  return coalesce((select jsonb_agg(to_jsonb(t)) from (
    select phone, name, premium_until, created_at, last_seen, is_admin from public.profiles
     where coalesce(p_q, '') = '' or phone like '%' || p_q || '%' or coalesce(name, '') ilike '%' || p_q || '%'
     order by created_at desc limit least(greatest(p_limit, 1), 200)) t), '[]'::jsonb);
end $$;

create or replace function public.admin_payments(p_limit int default 50) returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'forbidden'; end if;
  return coalesce((select jsonb_agg(to_jsonb(t)) from (
    select id, phone, amount, status, source, error, created_at from public.payments
     where status <> 'pending' order by id desc limit least(greatest(p_limit, 1), 200)) t), '[]'::jsonb);
end $$;

create or replace function public.admin_grant(p_phone text, p_days int) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_uid uuid; v_until timestamptz;
begin
  if not public.is_admin() then raise exception 'forbidden'; end if;
  if p_days is null or p_days < 1 or p_days > 3650 then raise exception 'bad_days'; end if;
  update public.profiles
     set premium_until = greatest(now(), coalesce(premium_until, now())) + make_interval(days => p_days)
   where phone = p_phone returning id, premium_until into v_uid, v_until;
  if v_uid is null then raise exception 'user_not_found'; end if;
  insert into public.payments(user_id, phone, sku, amount, status, source, payload)
  values (v_uid, p_phone, 'ADMIN', 0, 'success', 'admin', 'admin grant ' || p_days || 'd');
  return jsonb_build_object('premium_until', v_until);
end $$;

create or replace function public.admin_revoke(p_phone text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'forbidden'; end if;
  update public.profiles set premium_until = null where phone = p_phone;
  if not found then raise exception 'user_not_found'; end if;
end $$;

create or replace function public.admin_set_price(p_amount int) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'forbidden'; end if;
  if p_amount is null or p_amount < 1000 or p_amount > 100000000 then raise exception 'bad_price'; end if;
  insert into public.app_settings(key, value) values ('monthly_price', to_jsonb(p_amount))
  on conflict (key) do update set value = excluded.value;
end $$;

revoke execute on function public.admin_stats(), public.admin_users(text, int), public.admin_payments(int),
  public.admin_grant(text, int), public.admin_revoke(text), public.admin_set_price(int) from public, anon;
grant execute on function public.admin_stats(), public.admin_users(text, int), public.admin_payments(int),
  public.admin_grant(text, int), public.admin_revoke(text), public.admin_set_price(int) to authenticated;
revoke execute on function public.begin_payment(text), public.complete_payment(bigint, jsonb), public.fail_payment(bigint, text, text) from public, anon;
grant execute on function public.begin_payment(text), public.complete_payment(bigint, jsonb), public.fail_payment(bigint, text, text) to authenticated;
grant execute on function public.get_price(), public.track_install(text, text) to anon, authenticated;
