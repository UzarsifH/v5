-- FORJA RPC signature fix
-- Run this once in Supabase SQL Editor if the existing project already has the old function.

drop function if exists public.forja_api(jsonb,text,text,text,text);
drop function if exists public.forja_api(text,text,jsonb,text,text);

create or replace function public.forja_api(
  p_body jsonb default '{}'::jsonb,
  p_install_id text default null,
  p_method text default 'GET',
  p_path text default '',
  p_token text default null
) returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$

declare
  u forja_users%rowtype;
  target forja_users%rowtype;
  sub forja_subscriptions%rowtype;
  pay forja_payments%rowtype;
  v_token text;
  v_path text := lower(coalesce(p_path,''));
  v_method text := upper(coalesce(p_method,'GET'));
  v_phone text;
  v_password text;
  v_name text;
  v_price bigint;
  v_sku text;
  v_mode text;
  v_pkg text;
  v_rsa text;
  v_payload text;
  v_amount bigint;
  v_expires timestamptz;
  v_plan_id bigint;
  v_bmi numeric;
  v_height numeric;
  v_weight numeric;
  v_purchase jsonb;
  v_install text;
  v_total bigint;
  v_success bigint;
  v_failed bigint;
  v_installs bigint;
  v_revenue bigint;
  v_days integer;
begin
  -- Unique installation count is server-side and survives reinstall only when the OS/app
  -- preserves the local install identifier. A new installation is counted as a new install.
  v_install := nullif(trim(coalesce(p_install_id,'')), '');
  if v_install is not null then
    insert into forja_installations(install_id,user_id)
    values(v_install,null)
    on conflict(install_id) do update set last_seen_at=now();
  end if;

  -- Resolve session.
  if p_token is not null and length(p_token) > 10 then
    select s_user.* into u
    from forja_sessions s join forja_users s_user on s_user.id=s.user_id
    where s.token=p_token and s.expires_at > now()
    limit 1;
  end if;

  if u.id is not null and v_install is not null then
    update forja_installations set user_id=u.id,last_seen_at=now() where install_id=v_install;
    update forja_users set last_seen_at=now() where id=u.id;
  end if;

  -- AUTH
  if v_path='/auth/register' and v_method='POST' then
    v_phone := regexp_replace(coalesce(p_body->>'phone',''),'[^0-9]','','g');
    if left(v_phone,2)='98' and length(v_phone)=12 then v_phone := '0'||right(v_phone,10); end if;
    if length(v_phone)=10 and left(v_phone,1)='9' then v_phone := '0'||v_phone; end if;
    v_password := coalesce(p_body->>'password','');
    v_name := nullif(left(trim(coalesce(p_body->>'name','')),40),'');
    if v_phone !~ '^09[0-9]{9}$' then return jsonb_build_object('ok',false,'error','شماره موبایل معتبر نیست'); end if;
    if length(v_password)<6 then return jsonb_build_object('ok',false,'error','رمز عبور حداقل ۶ کاراکتر باشد'); end if;
    if exists(select 1 from forja_users where phone=v_phone) then return jsonb_build_object('ok',false,'error','این شماره قبلاً ثبت شده. وارد شو.'); end if;
    insert into forja_users(phone,password_hash,name,last_seen_at)
    values(v_phone,extensions.crypt(v_password,extensions.gen_salt('bf')),v_name,now())
    returning * into u;
    v_token := encode(extensions.gen_random_bytes(32),'hex');
    insert into forja_sessions(token,user_id,expires_at) values(v_token,u.id,now()+interval '90 days');
    if v_install is not null then update forja_installations set user_id=u.id where install_id=v_install; end if;
    return jsonb_build_object('ok',true,'token',v_token,'user',jsonb_build_object('id',u.id,'phone',u.phone,'name',u.name,'role',u.role));
  end if;

  if v_path='/auth/login' and v_method='POST' then
    v_phone := regexp_replace(coalesce(p_body->>'phone',''),'[^0-9]','','g');
    if left(v_phone,2)='98' and length(v_phone)=12 then v_phone := '0'||right(v_phone,10); end if;
    if length(v_phone)=10 and left(v_phone,1)='9' then v_phone := '0'||v_phone; end if;
    v_password := coalesce(p_body->>'password','');
    select * into target from forja_users where phone=v_phone limit 1;
    if target.id is null or target.password_hash <> extensions.crypt(v_password,target.password_hash) then
      return jsonb_build_object('ok',false,'error','شماره یا رمز اشتباه است');
    end if;
    update forja_users set last_seen_at=now() where id=target.id returning * into u;
    v_token := encode(extensions.gen_random_bytes(32),'hex');
    insert into forja_sessions(token,user_id,expires_at) values(v_token,u.id,now()+interval '90 days');
    if v_install is not null then update forja_installations set user_id=u.id,last_seen_at=now() where install_id=v_install; end if;
    return jsonb_build_object('ok',true,'token',v_token,'user',jsonb_build_object('id',u.id,'phone',u.phone,'name',u.name,'role',u.role));
  end if;

  if v_path='/auth/logout' and v_method='POST' then
    if p_token is not null then delete from forja_sessions where token=p_token; end if;
    return jsonb_build_object('ok',true);
  end if;

  if v_path='/auth/me' and v_method='GET' then
    if u.id is null then return jsonb_build_object('ok',true,'user',null); end if;
    select * into sub from forja_subscriptions
      where user_id=u.id and status='active' and expires_at>now()
      order by expires_at desc limit 1;
    return jsonb_build_object('ok',true,'user',jsonb_build_object(
      'id',u.id,'phone',u.phone,'name',u.name,'role',u.role,'createdAt',u.created_at,
      'isPremium',sub.id is not null,'premiumUntil',sub.expires_at,
      'hasPlan',exists(select 1 from forja_plans where user_id=u.id),
      'hasAssessment',exists(select 1 from forja_assessments where user_id=u.id)
    ));
  end if;

  if v_path='/config' and v_method='GET' then
    select coalesce((select value::bigint from forja_settings where key='monthly_price'),249000) into v_price;
    select coalesce((select value from forja_settings where key='payment_mode'),'live') into v_mode;
    select coalesce((select value from forja_settings where key='myket_sku_monthly'),'M2') into v_sku;
    select coalesce((select value from forja_settings where key='myket_package_name'),'ir.forja.app') into v_pkg;
    select coalesce((select value from forja_settings where key='myket_rsa_public_key'),'') into v_rsa;
    return jsonb_build_object('ok',true,'monthlyPrice',v_price,'paymentMode',v_mode,'sku',v_sku,'packageName',v_pkg,'rsaPublicKey',v_rsa,'appName','فُرجا');
  end if;

  if u.id is null then return jsonb_build_object('ok',false,'error','وارد حساب شو'); end if;

  -- PROFILE / ASSESSMENT / PLAN
  if v_path='/profile' and v_method='GET' then
    return jsonb_build_object(
      'ok',true,
      'user',jsonb_build_object('id',u.id,'phone',u.phone,'name',u.name,'role',u.role,'createdAt',u.created_at,
        'isPremium',exists(select 1 from forja_subscriptions where user_id=u.id and status='active' and expires_at>now()),
        'premiumUntil',(select max(expires_at) from forja_subscriptions where user_id=u.id and status='active' and expires_at>now()),
        'hasPlan',exists(select 1 from forja_plans where user_id=u.id),
        'hasAssessment',exists(select 1 from forja_assessments where user_id=u.id)),
      'payments',coalesce((select jsonb_agg(to_jsonb(x) order by x.id desc) from (
        select id,user_id as "userId",amount,status,gateway,sku,purchase_token as "purchaseToken",order_id as "orderId",payload,raw,created_at as "createdAt" from forja_payments where user_id=u.id
      ) x),'[]'::jsonb),
      'subscriptions',coalesce((select jsonb_agg(to_jsonb(x) order by x.id desc) from (
        select id,user_id as "userId",status,plan,amount,started_at as "startedAt",expires_at as "expiresAt",myket_sku as "myketSku",myket_token as "myketToken",myket_order_id as "myketOrderId",payload,created_at as "createdAt" from forja_subscriptions where user_id=u.id
      ) x),'[]'::jsonb)
    );
  end if;

  if v_path='/profile' and v_method='POST' then
    v_name := nullif(left(trim(coalesce(p_body->>'name','')),40),'');
    if v_name is null then return jsonb_build_object('ok',false,'error','نام را وارد کن'); end if;
    update forja_users set name=v_name where id=u.id;
    return jsonb_build_object('ok',true,'name',v_name);
  end if;

  if v_path='/assessment' and v_method='GET' then
    return jsonb_build_object('ok',true,'assessment',
      (select to_jsonb(x) from (select id,user_id as "userId",answers,height,weight,bmi,created_at as "createdAt" from forja_assessments where user_id=u.id order by id desc limit 1) x));
  end if;

  if v_path='/assessment' and v_method='POST' then
    if not exists(select 1 from forja_subscriptions where user_id=u.id and status='active' and expires_at>now()) then
      return jsonb_build_object('ok',false,'error','برای دریافت برنامه اختصاصی باید اشتراک فعال داشته باشی');
    end if;
    v_height := nullif((p_body->>'height')::numeric,0);
    v_weight := nullif((p_body->>'weight')::numeric,0);
    if v_height is null or v_weight is null or v_height<120 or v_height>230 or v_weight<35 or v_weight>220 then
      return jsonb_build_object('ok',false,'error','قد یا وزن معتبر نیست');
    end if;
    v_bmi := round(v_weight / power(v_height/100,2),2);
    insert into forja_assessments(user_id,answers,height,weight,bmi)
      values(u.id,p_body,v_height,v_weight,v_bmi);
    insert into forja_plans(user_id,title,summary,duration_weeks,days_per_week,plan)
      values(u.id,coalesce(p_body->>'planTitle','برنامه اختصاصی فُرجا'),p_body->>'planSubtitle',4,coalesce((p_body->>'daysPerWeek')::int,3),coalesce(p_body->'plan','{}'::jsonb))
      returning id into v_plan_id;
    return jsonb_build_object('ok',true,'planId',v_plan_id,'plan',coalesce(p_body->'plan','{}'::jsonb));
  end if;

  if v_path='/plan' and v_method='GET' then
    select id into v_plan_id from forja_plans where user_id=u.id order by id desc limit 1;
    if v_plan_id is null then
      return jsonb_build_object('ok',true,'plan',null,'freeSession',jsonb_build_object('enabled',true),'completions','[]'::jsonb,'logs','[]'::jsonb);
    end if;
    return jsonb_build_object(
      'ok',true,'planId',v_plan_id,
      'plan',(select plan from forja_plans where id=v_plan_id),
      'createdAt',(select created_at from forja_plans where id=v_plan_id),
      'completions',coalesce((select jsonb_agg(to_jsonb(x) order by x.id) from (select id,user_id as "userId",plan_id as "planId",day_index as "dayIndex",calories,duration_sec as "durationSec",xp,completed_at as "completedAt" from forja_day_completions where user_id=u.id and plan_id=v_plan_id) x),'[]'::jsonb),
      'logs',coalesce((select jsonb_agg(to_jsonb(x) order by x.id) from (select id,user_id as "userId",plan_id as "planId",day_index as "dayIndex",exercise_id as "exerciseId",status,sets_done as "setsDone",duration_sec as "durationSec",created_at as "createdAt" from forja_workout_logs where user_id=u.id and plan_id=v_plan_id) x),'[]'::jsonb),
      'freeSession',jsonb_build_object('enabled',true)
    );
  end if;

  -- PROGRESS
  if v_path='/progress' and v_method='GET' then
    select coalesce(sum(x.xp),0) into v_total from forja_day_completions x where x.user_id=u.id;
    return jsonb_build_object(
      'ok',true,
      'weights',coalesce((select jsonb_agg(to_jsonb(x) order by x.id desc) from (select id,user_id as "userId",weight,note,created_at as "createdAt" from forja_weight_logs where user_id=u.id) x),'[]'::jsonb),
      'days',coalesce((select jsonb_agg(to_jsonb(x) order by x.id desc) from (select id,user_id as "userId",plan_id as "planId",day_index as "dayIndex",calories,duration_sec as "durationSec",xp,completed_at as "completedAt" from forja_day_completions where user_id=u.id) x),'[]'::jsonb),
      'badges',coalesce((select jsonb_agg(to_jsonb(x) order by x.id desc) from (select id,user_id as "userId",code,title,unlocked_at as "unlockedAt" from forja_achievements where user_id=u.id) x),'[]'::jsonb),
      'stats',jsonb_build_object(
        'xp',v_total,'calories',coalesce((select sum(calories) from forja_day_completions where user_id=u.id),0),
        'workouts',(select count(*) from forja_day_completions where user_id=u.id),
        'exercises',(select count(*) from forja_workout_logs where user_id=u.id and status='completed'),
        'level',greatest(1,floor(v_total/250)+1)
      )
    );
  end if;

  if v_path='/progress' and v_method='POST' then
    v_weight := replace(coalesce(p_body->>'weight',''),',','.')::numeric;
    if v_weight is null or v_weight<30 or v_weight>250 then return jsonb_build_object('ok',false,'error','وزن معتبر نیست'); end if;
    insert into forja_weight_logs(user_id,weight,note) values(u.id,v_weight,nullif(p_body->>'note',''));
    return jsonb_build_object('ok',true,'saved',true);
  end if;

  if v_path='/workout/log' and v_method='POST' then
    insert into forja_workout_logs(user_id,plan_id,day_index,exercise_id,status,sets_done,duration_sec)
    values(u.id,coalesce((p_body->>'planId')::bigint,0),(p_body->>'dayIndex')::int,p_body->>'exerciseId',p_body->>'status',
      coalesce((p_body->>'setsDone')::int,0),coalesce((p_body->>'durationSec')::int,0));
    return jsonb_build_object('ok',true,'saved',true);
  end if;

  if v_path='/workout/log' and v_method='PUT' then
    insert into forja_day_completions(user_id,plan_id,day_index,calories,duration_sec,xp)
    values(u.id,coalesce((p_body->>'planId')::bigint,0),(p_body->>'dayIndex')::int,coalesce((p_body->>'calories')::int,0),
      coalesce((p_body->>'durationSec')::int,0),coalesce((p_body->>'xp')::int,80));
    select count(*) into v_total from forja_day_completions where user_id=u.id;
    if v_total>=1 then insert into forja_achievements(user_id,code,title) values(u.id,'first_workout','اولین جلسه فورج شد') on conflict do nothing; end if;
    if v_total>=7 then insert into forja_achievements(user_id,code,title) values(u.id,'week_warrior','۷ جلسه کامل') on conflict do nothing; end if;
    if v_total>=20 then insert into forja_achievements(user_id,code,title) values(u.id,'iron_will','اراده آهنی') on conflict do nothing; end if;
    return jsonb_build_object('ok',true,'completed',true);
  end if;

  -- MYKET
  if v_path='/payment/myket/init' and v_method='POST' then
    if exists(select 1 from forja_subscriptions where user_id=u.id and status='active' and expires_at>now()) then
      return jsonb_build_object('ok',false,'error','اشتراک فعال داری');
    end if;
    select coalesce((select value::bigint from forja_settings where key='monthly_price'),249000) into v_price;
    select coalesce((select value from forja_settings where key='myket_sku_monthly'),'M2') into v_sku;
    select coalesce((select value from forja_settings where key='myket_package_name'),'ir.forja.app') into v_pkg;
    select coalesce((select value from forja_settings where key='myket_rsa_public_key'),'') into v_rsa;
    v_payload := 'forja:'||u.id||':'||encode(extensions.gen_random_bytes(8),'hex');
    select * into pay from forja_payments where user_id=u.id and status='pending' order by id desc limit 1;
    if pay.id is null then
      insert into forja_payments(user_id,amount,status,gateway,sku,payload) values(u.id,v_price,'pending','myket',v_sku,v_payload) returning * into pay;
    else
      update forja_payments set amount=v_price,sku=v_sku,payload=v_payload,error_message=null where id=pay.id returning * into pay;
    end if;
    return jsonb_build_object('ok',true,'paymentId',pay.id,'amount',pay.amount,'sku',v_sku,'payload',v_payload,'packageName',v_pkg,'rsaPublicKey',v_rsa,'paymentMode','live');
  end if;

  if v_path='/payment/myket/verify' and v_method='POST' then
    select * into pay from forja_payments where id=(p_body->>'paymentId')::bigint and user_id=u.id for update;
    if pay.id is null then return jsonb_build_object('ok',false,'error','پرداخت پیدا نشد'); end if;
    if pay.status='paid' then return jsonb_build_object('ok',true,'already',true); end if;
    v_purchase := coalesce(p_body->'purchase','{}'::jsonb);
    if lower(coalesce(v_purchase->>'signatureVerified','false')) <> 'true' then
      return jsonb_build_object('ok',false,'error','امضای رسید مایکت معتبر نبود');
    end if;
    if coalesce(v_purchase->>'productId',v_purchase->>'sku','') <> pay.sku then return jsonb_build_object('ok',false,'error','SKU با محصول مایکت یکی نیست'); end if;
    if coalesce(v_purchase->>'developerPayload','') <> pay.payload then return jsonb_build_object('ok',false,'error','رسید مربوط به این پرداخت نیست'); end if;
    if nullif(v_purchase->>'purchaseToken','') is null then return jsonb_build_object('ok',false,'error','توکن خرید مایکت دریافت نشد'); end if;
    if exists(select 1 from forja_payments where status='paid' and purchase_token=v_purchase->>'purchaseToken') then return jsonb_build_object('ok',false,'error','این رسید قبلاً استفاده شده'); end if;
    v_expires := greatest(now(),coalesce((select max(expires_at) from forja_subscriptions where user_id=u.id and status='active'),now())) + interval '30 days';
    update forja_payments set status='paid',purchase_token=v_purchase->>'purchaseToken',order_id=v_purchase->>'orderId',raw=v_purchase,error_message=null where id=pay.id;
    insert into forja_subscriptions(user_id,status,plan,amount,started_at,expires_at,myket_sku,myket_token,myket_order_id,payload,source)
    values(u.id,'active','monthly',pay.amount,now(),v_expires,pay.sku,v_purchase->>'purchaseToken',v_purchase->>'orderId',pay.payload,'myket');
    return jsonb_build_object('ok',true,'activated',true,'expiresAt',v_expires);
  end if;

  if v_path='/payment/myket/fail' and v_method='POST' then
    update forja_payments set status='failed',error_message=left(coalesce(p_body->>'error','پرداخت ناموفق'),500),raw=p_body
    where id=(p_body->>'paymentId')::bigint and user_id=u.id and status='pending';
    return jsonb_build_object('ok',true);
  end if;

  -- ADMIN
  if v_path like '/admin/%' then
    if u.role <> 'admin' then return jsonb_build_object('ok',false,'error','دسترسی مدیر لازم است'); end if;

    if v_path='/admin/overview' and v_method='GET' then
      select count(*) into v_total from forja_users where role='user';
      select count(*) into v_success from forja_payments where status='paid';
      select count(*) into v_failed from forja_payments where status='failed';
      select count(*) into v_installs from forja_installations;
      select coalesce(sum(amount),0) into v_revenue from forja_payments where status='paid';
      select coalesce((select value::bigint from forja_settings where key='monthly_price'),249000) into v_price;
      return jsonb_build_object(
        'ok',true,'stats',jsonb_build_object('users',v_total,'successfulPurchases',v_success,'failedPurchases',v_failed,'installs',v_installs,'activeSubscriptions',(select count(*) from forja_subscriptions where status='active' and expires_at>now()),'revenue',v_revenue,'monthlyPrice',v_price),
        'users',coalesce((select jsonb_agg(to_jsonb(x) order by x.created_at desc) from (select id,phone,name,role,created_at as "createdAt",(select max(expires_at) from forja_subscriptions s where s.user_id=f.id and s.status='active' and s.expires_at>now()) as "premiumUntil" from forja_users f where role='user' limit 100) x),'[]'::jsonb)
      );
    end if;

    if v_path='/admin/price' and v_method='POST' then
      v_price := (p_body->>'price')::bigint;
      if v_price is null or v_price<0 then return jsonb_build_object('ok',false,'error','قیمت معتبر نیست'); end if;
      insert into forja_settings(key,value) values('monthly_price',v_price::text) on conflict(key) do update set value=excluded.value,updated_at=now();
      return jsonb_build_object('ok',true,'monthlyPrice',v_price);
    end if;

    if v_path='/admin/grant' and v_method='POST' then
      v_phone := regexp_replace(coalesce(p_body->>'phone',''),'[^0-9]','','g');
      if left(v_phone,2)='98' and length(v_phone)=12 then v_phone := '0'||right(v_phone,10); end if;
      select * into target from forja_users where phone=v_phone limit 1;
      if target.id is null then return jsonb_build_object('ok',false,'error','کاربر پیدا نشد'); end if;
      v_days := greatest(1,coalesce((p_body->>'days')::int,30));
      v_price := coalesce((select value::bigint from forja_settings where key='monthly_price'),249000);
      v_expires := greatest(now(),coalesce((select max(expires_at) from forja_subscriptions where user_id=target.id and status='active'),now())) + make_interval(days=>v_days);
      insert into forja_subscriptions(user_id,status,plan,amount,started_at,expires_at,source) values(target.id,'active','monthly',v_price,now(),v_expires,'admin');
      return jsonb_build_object('ok',true,'phone',target.phone,'expiresAt',v_expires);
    end if;

    if v_path='/admin/revoke' and v_method='POST' then
      v_phone := regexp_replace(coalesce(p_body->>'phone',''),'[^0-9]','','g');
      update forja_subscriptions set status='revoked' where user_id=(select id from forja_users where phone=v_phone) and status='active' and expires_at>now();
      return jsonb_build_object('ok',true);
    end if;
  end if;

  return jsonb_build_object('ok',false,'error','مسیر پیدا نشد');
exception when others then
  return jsonb_build_object('ok',false,'error','خطای سرور: '||left(sqlerrm,250));
end;
$$;

revoke all on function public.forja_api(jsonb,text,text,text,text) from public;
grant execute on function public.forja_api(jsonb,text,text,text,text) to anon, authenticated;
notify pgrst, 'reload schema';
